---
name: html-deploy-ai-edit
description: 给本地 HTML 加上"AI 实时改稿"能力——同事/老板在评论里写诉求，DeepSeek 直接把 HTML 改了，版本可撤回。这是 html-deploy-comments 之上的最高阶增值 skill，需要 DeepSeek API key，比纯评论版本不稳定。当用户说"AI 改 HTML"、"AI 实时改方案"、"评论说改就改"时使用。
version: 1.0.0
agent_created: true
---

# 给 HTML 加 AI 实时改稿

⚠️ **稳定性低于纯评论版**——AI 调用涉及跨域、密码加密、DOM patch、版本撤回多个环节，任何一处问题都会让整套链路失败。**生产场景强烈建议先用 `html-deploy-comments` 跑稳，确实需要再加 AI。**

---

## 何时用

- 想让评论的人不光提建议，还能让 AI 当场改 HTML（小幅文案/样式调整）
- 接受 AI 偶尔改错（提供版本撤回作为兜底）
- 愿意为 DeepSeek API 付钱（5 元能用很久）

## 何时不用

- 老板只看不评 → `html-deploy-github`
- 老板要评论但不要 AI → `html-deploy-comments`（推荐 90% 场景用这个）
- 改稿幅度大、精度要求高 → 直接让 WorkBuddy 改源 HTML 重新部署，比 AI 当场改靠谱

---

## 关键事实（先看完再决定要不要装）

1. **AI Provider 必须用 DeepSeek**——腾讯混元等不支持浏览器 CORS 跨域，会 `Failed to fetch`
2. **API key 用 AES-GCM 加密嵌入 HTML**——访问者要输入密码才能解密，否则用不了 AI（但能看能评论）
3. **改一次约 3-15 秒**——取决于 DeepSeek 负载和 HTML 大小
4. **版本撤回**：每次 AI 改之前自动 snapshot 整个 container 存 Gist，错了能撤
5. **不是所有 HTML 都能用**——DOM 必须有 commentable 锚点 + 完整的 sectionNames + TARGET_SELECTORS 配置

---

## 实现路径：复用 html-report-publisher 的完整版

由于 AI 模块和评论、版本撤回、密码门、护栏深度耦合，独立拆出来不划算。**本 skill 直接调用 `html-report-publisher` 的完整版生成路径**。

### 流程

```
Step 1  前置检查：DeepSeek API key + 共享 GitHub 配置
  ↓
Step 2  跳到 html-report-publisher 完整版流程：
        cp templates/reference.html → 注入正文 → deploy
  ↓
Step 3  打开 URL 验证 AI 能改
```

### Step 1：前置检查

#### 1a. GitHub 配置（共享）

```bash
python3 ~/.workbuddy/skills/html-deploy-github/scripts/setup.py --check
```

#### 1b. DeepSeek API Key

打开 https://platform.deepseek.com/ → 注册 → 充 5 元 → 创建 API Key → 复制 `sk-xxx`。

写到 `~/.workbuddy/skills/html-report-publisher/config.json` 的 `ai_api_key` 字段。如果该 config 不存在：

```bash
# 引导式创建
python3 << 'PY'
import json, os, pathlib, getpass
shared = json.load(open(pathlib.Path.home() / '.workbuddy/skills/.shared/github.json'))
gist_id = input('Gist ID (用于版本撤回; 复用 comments skill 的也可): ').strip()
ai_key = getpass.getpass('DeepSeek API key (sk-xxx): ').strip()
repo = input('部署仓库名: ').strip()
pwd = input('访问密码（同事打开链接用 AI 时要输）: ').strip()
cfg = {
  'github_token': shared['github_token'],
  'github_user': shared['github_user'],
  'gist_id': gist_id,
  'enable_ai': True,
  'ai_provider': 'deepseek',
  'ai_api_key': ai_key,
  'ai_endpoint': 'https://api.deepseek.com/v1/chat/completions',
  'ai_model': 'deepseek-chat',
  'deploy_repo': repo,
  'deploy_password': pwd,
}
p = pathlib.Path.home() / '.workbuddy/skills/html-report-publisher/config.json'
p.write_text(json.dumps(cfg, indent=2, ensure_ascii=False))
os.chmod(p, 0o600)
print('✓', p)
PY
```

### Step 2：生成 + 注入 + 部署

```bash
# 1) 用完整版骨架
cp ~/.workbuddy/skills/html-report-publisher/templates/reference.html <out_path>

# 2) 把你的方案正文注入到 .container（必须包 .commentable + data-section）
#    修改 sectionNames（中文映射）+ TARGET_SELECTORS（text/image/data 三组选择器）

# 3) 部署
python3 ~/.workbuddy/skills/html-report-publisher/scripts/deploy.py <out_path> --force-local
```

详细的注入和配置规则参考 `~/.workbuddy/skills/html-report-publisher/SKILL.md`（含完整版的全部铁律和故障排查）。

### Step 3：验证

打开返回的 URL：
1. 切到「批注」模式 → 点页面元素 → 选「✨ AI 修改」
2. 第一次会弹密码框 → 输 deploy 时设的密码
3. 描述改动（"标题加个 emoji"） → 等 5-10 秒 → 看到生效
4. 顶栏「版本历史」可撤回

如果第一步密码弹窗被 toast 遮挡或 unlockKeys 失败，参考 publisher SKILL.md 故障排查表。

---

## 与 comments skill 的关系

| 特性 | comments | ai-edit |
|---|---|---|
| 评论 | ✅ 自研轻量模块 | ✅ 用 publisher 完整版 |
| AI 改稿 | ❌ | ✅ |
| 版本撤回 | ❌ | ✅ |
| 密码门 | ❌（Gist 直接读写） | ✅（AES-GCM） |
| 注入对象 | 任意 HTML | 必须基于 reference.html 模板 |
| 稳定性 | 高（功能少、依赖少） | 中（多组件耦合） |
| 适用场景 | 90% 在线评审 | 高频迭代、需当场改稿 |

**核心建议**：先 `html-deploy-comments`，跑稳两轮再升级到 ai-edit。不要一上来就上 AI——大部分汇报场景评论就够了。

---

## 故障排查（AI 专属）

| 症状 | 原因 → 解决 |
|---|---|
| `Failed to fetch` 调 AI | 用了腾讯混元等 → 必须 DeepSeek |
| 点 AI 修改无密码弹窗 | toast 在 unlock 之前 → 看 publisher SKILL.md 铁律 |
| 密码弹窗被 toast 遮挡 | 用了原生 prompt → 改自定义 modal |
| AI "已执行" 但页面没变 | applyAIResultMulti 吞错 → 看 publisher 故障排查 |
| 刷新后 AI 修改回到改之前 | latest/versions 混用 → 已修，更新到 reference.html v2.11.23+ |
| 改一次要 30 秒 | DeepSeek 高峰期 → 等等或换时段 |
| 401 DeepSeek | API key 失效或欠费 → 重新生成 |

---

## 文件结构

本 skill 是**轻量包装层**——核心代码在 `html-report-publisher`：

```
html-deploy-ai-edit/
└── SKILL.md   （只有引导，没有独立脚本）
```

依赖：
- `html-deploy-github`（共享 token）
- `html-report-publisher`（reference.html 模板 + deploy.py 完整版）

---

## 复用要点（执行前自检）

1. ✅ DeepSeek API key 必备，5 元起
2. ✅ HTML 必须基于 reference.html 重新生成，不能在任意 HTML 上叠加
3. ✅ 提醒用户：AI 改稿适合小幅微调，大改还是手改源文件
4. ✅ 部署前必跑 publisher 的 verify.py
5. ✅ 第一次部署用 `--force-local`
