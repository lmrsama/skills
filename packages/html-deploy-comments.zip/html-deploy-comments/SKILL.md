---
name: html-deploy-comments
description: 给任意 HTML 加"在线评论 + 点赞 + 浏览量"能力，访客打开链接直接点评，多端秒级同步。后端走腾讯云 SCF + GitHub Gist，前端不含任何 token，永不被 revoke。当用户说「让老板能评论我的方案」「HTML 加评论」「给网页加点赞」「在线评审」「实时评论」时使用。
version: 2.0.0
agent_created: true
---

# 💬 HTML 在线评论/点赞/浏览量

给任意 HTML 加"访客零门槛评论 + 点赞 + 浏览量"，评论上云多端秒级同步。**密钥永不暴露、永不被 revoke**。

---

## 核心架构（必读，10 秒看懂）

```
访客浏览器          腾讯云 SCF           GitHub Gist
   │                  │ (持 PAT)           │
   │  写评论          │                    │
   ├─────────────────>│ 校验密码+昵称+Origin
   │  (无 token)      │                    │
   │                  ├───PATCH───────────>│
   │                  │                    │
   │   OK             │                    │
   │<─────────────────┤<───────────────────┤
```

**核心原则**：
- **token 只存 SCF 环境变量**，前端代码里没有任何 GitHub 凭证
- 前端 fetch 只认 SCF URL，带密码调用
- GitHub 永远扫不到 token → 永远不会 revoke

**这条架构踩过的坑（不要再走）**：
- ❌ 前端嵌明文 token（`PUBLIC_GIST_TOKEN`）→ GitHub secret-scanning 几小时内 revoke
- ❌ 密码加密 token 放前端 → 加密也没用，token 字符串模式被扫到就 revoke
- ❌ Cloudflare Worker 的 `*.workers.dev` → 国内 DNS 被污染，访问不到
- ✅ **腾讯云 SCF + 函数 URL**：国内访问稳、不被污染、token 不暴露

---

## 依赖

- 基础：`html-deploy-github`（部署 HTML 到 Pages）
- 可选：`html-deploy-ai-edit`（AI 实时改稿）

---

## 首次配置（15 分钟，一次配置终身受用）

### 1. 创建 Gist 当数据库

去 https://gist.github.com/ 新建一个 **Public** gist：

- 文件名 1：`comments.json`，内容：`{}`
- 文件名 2：`latest.json`，内容：`{}`
- 文件名 3：`versions.json`，内容：`[]`

创建后复制 gist id（URL 里那串 hash）。

### 2. 生成 fine-grained PAT

https://github.com/settings/personal-access-tokens/new

- Resource owner：选你自己
- Repository access：Public repositories (read-only)
- **Permissions → Account permissions → Gists**：**Read and write**
- 其他全不勾
- 过期时间 90 天

生成后**立即复制** token（关闭页面就看不到了）。

### 3. 部署腾讯云 SCF

登录 https://console.cloud.tencent.com/scf（工作微信扫码）

**新建函数**：
- 地域：广州
- 函数名：`qb-report-relay`（或自定义）
- 运行环境：Node.js 18.15
- 创建方式：空白函数
- 代码：把 `scf/index.js` 内容粘进去
- 入口函数：`index.main_handler`

**环境变量**（高级配置 → 环境变量）：

| Key | Value |
|---|---|
| `GITHUB_PAT` | 步骤 2 的 token |
| `GIST_ID` | 步骤 1 的 gist id |
| `ACCESS_PASSWORD` | 自定义写评论密码 |
| `ALLOWED_ORIGIN` | 你的 Pages 地址，如 `https://lmrsama.github.io` |
| `STATS_GIST_ID` | **可选**，skills 官网点赞/浏览量 gist（见 `scf/README.md`） |

**触发器**：**暂不创建**（用函数 URL，不是 API 网关）

**创建完成后** → 函数详情 → **函数 URL 配置** → 新建：
- 公网访问：**启用** ⚠️
- CORS：**启用** ⚠️
- Allow-Origin：`*`
- Allow-Methods：勾 `GET`、`POST`、`OPTIONS`
- Allow-Headers：`*`
- **Expose-Headers：留空**（填了括号之类会报 `Invalid ExposeHeaders`）
- Max-Age：`86400`
- 授权类型：开放
- 参数兼容：**启用** ⚠️

保存后复制 URL（形如 `https://xxx.ap-guangzhou.tencentscf.com`）。

### 4. 写入 skill config

```bash
# 编辑
vim ~/.workbuddy/skills/html-deploy-comments/config.json
```

```json
{
  "scf_url": "https://xxx.ap-guangzhou.tencentscf.com",
  "gist_id": "你的 gist id",
  "access_password": "你定的密码",
  "pages_origin": "https://lmrsama.github.io"
}
```

### 5. 自测 SCF

```bash
URL="你的 SCF URL"
curl $URL/health
# 期望：{"ok":true,"features":{"gist_relay":true,...}}

curl $URL/gist
# 期望：{"files":{...}}

curl -X POST $URL/gist/file \
  -H "Content-Type: application/json" \
  -H "Origin: https://lmrsama.github.io" \
  -d '{"password":"你的密码","nickname":"test","filename":"comments.json","content":"{\"all\":[]}"}'
# 期望：{"ok":true,...}
```

---

## 使用

### 给现有 HTML 注入评论能力

```bash
python3 ~/.workbuddy/skills/html-deploy-comments/scripts/inject.py 你的文件.html
```

脚本会：
1. 读 `config.json` 里的 `scf_url` / `gist_id` / `access_password` / `pages_origin`
2. 把 CSS / JS / 必要 DOM 注入到 HTML
3. 替换占位符 `__SCF_URL__`、`__GIST_ID__`、`__ACCESS_PASSWORD_HINT__`、`__PAGES_ORIGIN__`

完成后用 `html-deploy-github` 部署上线：

```bash
python3 ~/.workbuddy/skills/html-deploy-github/scripts/deploy.py 你的文件.html --repo 你的repo
```

### 写评论流程（访客视角）

1. 打开链接 → 立刻看到历史评论（无密码）
2. 点"发布" → 弹昵称框（首次）→ 弹密码框（首次，作者告诉访客）
3. 之后这台浏览器都不再问

---

## 旋转 PAT

1. GitHub revoke 旧 PAT → 生成新 PAT
2. SCF 控制台 → 函数管理 → 环境变量 → 改 `GITHUB_PAT` → 保存
3. 前端零改动

---

## 目录结构

```
html-deploy-comments/
├── SKILL.md             # 本文件
├── config.json          # scf_url / gist_id / access_password / pages_origin
├── scripts/
│   └── inject.py        # 注入到现有 HTML
├── snippets/
│   ├── comments.css     # 评论 UI 样式
│   └── comments.js      # 前端逻辑（gistGet / gistWrite / 昵称密码弹窗）
└── scf/
    ├── index.js         # 腾讯云 SCF 函数代码
    └── README.md        # SCF 详细部署指南
```

---

## 故障排查

| 症状 | 原因 | 解法 |
|---|---|---|
| 评论点不动 | 页面有 document 级 click handler 拦截 | inject 出的代码已经自带 stopPropagation，应该没这问题 |
| 401 password incorrect | SCF 环境变量里的密码跟 config 不一致 | 去 SCF 控制台对一下 |
| 403 origin not allowed | SCF 里 `ALLOWED_ORIGIN` 没包含你的 Pages 域名 | 环境变量加上 |
| CORS 预检失败 | SCF 函数 URL 没开 CORS 或方法没勾全 | 重新配函数 URL，CORS 启用、GET/POST/OPTIONS 全勾 |
| 评论写不上（curl 能通，网页不能） | `ALLOWED_ORIGIN` 和实际页面 Origin 不一致（注意 http/https） | 核对 |
| fine-grained PAT 被 revoke | 理论上 SCF 里的不会，除非你不小心把 token 贴到某个公开仓库 | 生成新的，只改 SCF env |
