---
name: html-deploy-comments
description: 给本地 HTML 加上"在线评论模块"——同事打开 GitHub Pages 链接就能在页面元素上点击留言，评论存 Gist 多人多端实时同步。这是 html-deploy-github 的增值 skill，依赖它来部署上线。当用户说"加评论功能"、"让老板能在方案上评论"、"HTML 在线评审"、"在网页上批注"时使用。
version: 1.0.0
agent_created: true
---

# 给 HTML 加评论模块

往任意本地 HTML 注入评论 UI（顶部工具条 + 选中元素 + 气泡留言 + 侧边面板 + 导出 Markdown），评论存 GitHub Gist，多人多端实时看到。

依赖：`html-deploy-github`（用它部署上线，本 skill 只负责"加功能"）。

---

## 何时用

- 用户已经有本地 HTML（任何来源都行：方案、数据看板、demo）
- 想发链接给同事/老板，让他们直接在页面上点元素留言
- 评论要持久化、跨设备同步、能导出 Markdown 给作者整理

## 何时不用

- 只想发个静态链接看 → 用 `html-deploy-github`
- 还要 AI 帮我改方案 → 加用 `html-deploy-ai-edit`（在评论之上叠加）

---

## 执行流程

```
Step 1  前置检查（共享 GitHub 配置 + 评论 Gist）
  ↓
Step 2  注入评论模块到本地 HTML
  ↓
Step 3  用 html-deploy-github 部署上线
```

---

## Step 1：前置检查

### 1a. 共享 GitHub 配置

```bash
python3 ~/.workbuddy/skills/html-deploy-github/scripts/setup.py --check
```

输出 `✓ token valid` 才能继续。否则跑 `setup.py` 引导。

⚠️ 评论模块需要 token 有 **gist 权限**（写评论数据要 PATCH gist）。如果之前 setup 时没勾 gist scope，去 https://github.com/settings/tokens 给 token 补勾上。

### 1b. 评论专用 Gist

```bash
python3 ~/.workbuddy/skills/html-deploy-comments/scripts/inject.py --check
```

如果 `Comments gist : ✗`，跑：

```bash
python3 ~/.workbuddy/skills/html-deploy-comments/scripts/inject.py --setup-gist
```

自动创建一个 public Gist（含一个空 `comments.json`），gist_id 写入 `~/.workbuddy/skills/html-deploy-comments/config.json`。

⚠️ Gist 选 public 是因为 raw_url fallback（数据 > 1MB 时 GitHub API 会 truncate，需要从 raw_url 拉全文）。public 不影响安全：写还是要 token。

## Step 2：注入

```bash
python3 ~/.workbuddy/skills/html-deploy-comments/scripts/inject.py <html_path>
```

inject.py 自动：
1. 读 HTML，往 `</head>` 之前加 CSS（10KB）
2. 往 `</body>` 之前加 JS（含 GIST_ID + TOKEN 直接嵌入）
3. 自动给 `.container > *`、`main > *`、`article > *` 等显眼区块加 `.hdc-commentable` class
4. 备份原文件为 `.bak`，原地替换

如果想输出到新文件：

```bash
python3 inject.py source.html -o source-with-comments.html
```

### 自定义评论粒度

默认自动给容器顶级子元素加 `.hdc-commentable`。如果想精确控制：

- 在 HTML 里手动给元素加 `class="hdc-commentable"` 和（推荐）`data-section="标识符"`
- 一旦发现已存在 `.hdc-commentable`，inject.py 不会再自动标注（尊重用户意图）

`data-section` 的好处：DOM 重排后评论仍能找到锚点（不再依赖 nth-child path）。

## Step 3：部署

```bash
python3 ~/.workbuddy/skills/html-deploy-github/scripts/deploy.py <html_path> --repo <name>
```

完事。打开返回的 URL 即可看到顶栏多了「📝 在线评审」工具条。

---

## 评论模块功能

| 能力 | 描述 |
|---|---|
| 只读/批注切换 | 默认只读，切到「批注」才能点元素留言 |
| 选中高亮 | 点击 commentable 元素显示蓝色实线高亮 + 悬浮气泡 |
| 评论气泡 | 选中后顶部出 `💬 评论这里` 气泡，点击展开侧边面板 |
| 名字记忆 | 首次评论问名字，之后 localStorage 存（仅本设备） |
| 评论列表 | 侧边面板按时间倒序，点位置标签可跳转回原元素 |
| 导出 Markdown | 一键下载 `comments-YYYY-MM-DD.md`（含位置 + 作者 + 时间 + 内容） |
| 删除 | 只能删自己发的评论（按 author 字段判断） |
| 计数徽标 | 有评论的元素右上角红点标数字 |
| 移动端 | 顶栏自适应、面板全屏、字号适配 |

---

## 关键约束

⚠️ **token 直接明文嵌入 HTML**——这是必要的（前端要写 Gist）。如果担心 token 被滥用：
- 创建专门的 fine-grained PAT，只授权 Gist scope
- 不要在 HTML 里嵌入有 repo 权限的 token

⚠️ **评论是 public Gist**——任何拿到 gist_id 的人都能读。但要写还是必须有 token。

⚠️ **不要重复 inject**——`inject.py` 自检 `<!-- hdc-comments-injected -->` 标记，已注入会跳过 CSS/JS 仅刷新 GIST_ID/TOKEN。如果要强制重新注入：手动删 `.hdc-` 相关代码后再跑。

⚠️ **HTML 改了 DOM 结构后**：用 `data-section` 锚定的评论不受影响；用自动 path 锚定的可能找不到——会显示「该元素已删除」但评论数据不丢。

⚠️ **不要在公开聊天里发 token**：所有 setup/check 步骤都让用户去终端跑。

---

## 故障排查

| 症状 | 原因 → 解决 |
|---|---|
| 顶栏不显示 | inject 失败 / `</body>` 不存在 → 看 inject.py 输出；HTML 必须有 `</body>` |
| 评论列表为空但发不出 | gist_id 写错 / token 没 gist scope → `inject.py --check`；token 补 gist 权限 |
| `Failed to fetch` 评论 | 网络问题 / Gist 被删 → 检查 gist_id 在 https://gist.github.com 还存在 |
| 顶栏遮住页面顶部内容 | 没加 `body.hdc-has-toolbar` class → 检查 JS 是否真跑起来（控制台 `[hdc] auto-marked`）|
| 元素都不能点 | 没有 `.hdc-commentable` 元素 → 检查 HTML 结构有没有 `.container` / `main` / `article` |
| 重新部署后评论丢了 | 评论存 Gist 不存仓库，正常情况不会丢；如果丢了去 https://gist.github.com 看 gist 历史 |
| 选中态错位 | CSS 冲突（用户 HTML 里有同名 class） → 评论模块所有 class 都以 `hdc-` 开头，理论上不冲突；如果冲突手动改 inject.py 里的 class 名 |

---

## 文件结构

```
html-deploy-comments/
├── SKILL.md
├── config.json              （首次 setup-gist 后生成）
├── scripts/
│   └── inject.py            （核心：注入器 + setup-gist + check）
└── snippets/
    ├── comments.css         （注入到 <head>）
    └── comments.js          （注入到 <body>，占位符 __HDC_GIST_ID__ / __HDC_TOKEN__）
```

---

## 复用要点（执行前自检）

1. ✅ token 必须有 gist scope（重新 setup 或去 GitHub 补勾）
2. ✅ 评论 Gist 一次创建多次复用（多个 HTML 项目可以共享同一个 gist；评论里 target 字段是元素路径，不会串扰）
3. ✅ HTML 改大改后用 `data-section` 锚定评论，不要靠自动 path
4. ✅ 不要重复 inject，inject.py 已防护
5. ✅ 部署前可以先用 `python3 -m http.server` 在本地预览验证
