# 腾讯云 SCF 部署（10 分钟）

## 前置准备

1. **GitHub fine-grained PAT**
   - https://github.com/settings/personal-access-tokens/new
   - Permissions → Account → **Gists: Read and write**
   - 其他不勾，90 天有效

2. **两个 Gist**（都 Public）
   - 汇报评论 gist：3 个文件 `comments.json` / `latest.json` / `versions.json`
   - skills 站 stats gist（可选）：1 个文件 `site-stats.json`

## 创建 SCF 函数

1. 登录 https://console.cloud.tencent.com/scf（工作微信扫码）
2. 地域切到 **广州**
3. 函数服务 → 新建 → 从头开始
4. 函数配置：
   - 函数类型：事件函数
   - 函数名：`qb-report-relay`
   - 运行环境：Node.js 18.15
   - 创建方式：空白函数
5. 函数代码：把 `index.js` 内容粘贴进去，入口函数 `index.main_handler`

## 环境变量

| Key | 必填 | 说明 |
|---|---|---|
| `GITHUB_PAT` | ✅ | 步骤 1 生成的 PAT |
| `GIST_ID` | ✅ | 汇报评论 gist id |
| `ACCESS_PASSWORD` | ✅ | 写操作密码，访客输入 |
| `ALLOWED_ORIGIN` | ✅ | 允许的 Origin，如 `https://lmrsama.github.io`，多个逗号隔开 |
| `STATS_GIST_ID` | ❌ | skills 站 stats gist id（不配置则 stats 路由返回 501） |

## 触发器

**选「暂不创建」**——我们用函数 URL，不用 API 网关（腾讯云 API 网关已下线）。

## 开启函数 URL

函数详情 → **函数 URL 配置** → 新建：

| 项 | 值 |
|---|---|
| 公网访问 | ✅ **启用** |
| CORS | ✅ **启用** |
| Allow-Origin | `*` |
| Allow-Methods | 勾 `GET` `POST` `OPTIONS` |
| Allow-Headers | `*` |
| **Expose-Headers** | **留空**（填 `)` 等字符会报 Invalid ExposeHeaders） |
| Allow-Credentials | 不勾 |
| Max-Age | `86400` |
| 授权类型 | 开放 |
| 参数兼容 | ✅ **启用**（⚠️ 必须勾，否则 event 里拿不到 path/body） |

保存后拿到 URL，形如 `https://1406195631-xxx.ap-guangzhou.tencentscf.com`

## 路由速查

| Method | Path | 说明 | 鉴权 |
|---|---|---|---|
| GET | `/health` | 健康检查，看 features 状态 | 无 |
| GET | `/gist` | 读汇报评论 gist | 无 |
| POST | `/gist/file` | 写汇报评论 gist | password + nickname + Origin |
| GET | `/stats` | 读 skills 站 stats | 无 |
| POST | `/stats/view` | 浏览量自增 | visitorId + Origin |
| POST | `/stats/like` | 点赞 | visitorId + nickname + Origin |
| POST | `/stats/comment` | 发评论 | password + nickname + text + Origin |
| POST | `/stats/comment/delete` | 删评论 | password + ids + Origin |

## 自测

```bash
URL="你的 SCF URL"

curl $URL/health
# {"ok":true,"runtime":"tencent-scf","version":"v2.0","features":{"gist_relay":true,...}}

curl $URL/gist | head -c 200
# JSON 带 files 字段

curl -X POST $URL/gist/file \
  -H "Content-Type: application/json" \
  -H "Origin: https://lmrsama.github.io" \
  -d '{"password":"qb2026","nickname":"test","filename":"comments.json","content":"{\"all\":[]}"}'
# {"ok":true,...}
```

## 旋转 PAT

- GitHub revoke 旧 PAT → 生成新 PAT
- SCF 控制台 → 函数管理 → 环境变量 → 改 `GITHUB_PAT` → 保存
- **前端零改动**

## 常见坑

| 症状 | 根因 | 解法 |
|---|---|---|
| `{"error":"not found",...}` | path 带了奇怪前缀 | 代码里 `matches()` 已经兼容前缀；如果还不行看 event.path 日志 |
| 写失败 403 `origin not allowed` | `ALLOWED_ORIGIN` 不含请求源 | 环境变量加上（注意 http/https 严格匹配） |
| 写失败 401 `password incorrect` | 前端密码和环境变量不一致 | 对齐 |
| 写成功但 gist 没变 | 环境变量里 `GITHUB_PAT` 被 revoke | GitHub 撤销重建 |
| CORS 预检失败 | 函数 URL CORS 没开或 Allow-Methods 没勾 OPTIONS | 重新配 |
| 拿不到 body | 函数 URL 没勾「参数兼容」 | 勾上 |
