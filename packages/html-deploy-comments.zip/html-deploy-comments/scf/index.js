/**
 * QB Report Comment Relay - 腾讯云 SCF (Node.js 18+)
 *
 * v2.0：支持两种用途
 *   - 汇报 HTML 评论：透传 gist 读写（需密码）
 *   - skills 官网 stats：浏览量/点赞/评论（点赞+浏览免密码，评论要密码）
 *
 * 路由：
 *   GET  /health              → 健康检查
 *   GET  /gist                → 读汇报评论 gist
 *   POST /gist/file           → 写汇报评论 gist（需 password + nickname）
 *   GET  /stats               → 读 skills 官网 stats
 *   POST /stats/view          → 浏览量自增（无密码，需 visitorId）
 *   POST /stats/like          → 点赞（需 nickname，无密码）
 *   POST /stats/comment       → 发评论（需 nickname + password）
 *   POST /stats/comment/delete → 删评论（需 password）
 *
 * 环境变量：
 *   GITHUB_PAT        必填，fine-grained PAT，gist read/write
 *   GIST_ID           必填，汇报评论 gist id
 *   STATS_GIST_ID     可选，skills 官网 stats gist id（没配就不开放 stats 路由）
 *   ACCESS_PASSWORD   必填，写操作密码
 *   ALLOWED_ORIGIN    必填，逗号分隔白名单
 */

const ALLOWED_FILES = new Set(['comments.json', 'versions.json', 'latest.json']);
const STATS_FILENAME = 'site-stats.json';
const MAX_CONTENT_BYTES = 2 * 1024 * 1024;
const MAX_COMMENTS = 500; // skills 官网评论上限
const MAX_TEXT_LEN = 500;

function corsHeaders(origin) {
  return {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': origin || '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Max-Age': '86400',
    'Cache-Control': 'no-store',
  };
}

function apigwResponse(body, status, origin) {
  return {
    isBase64Encoded: false,
    statusCode: status,
    headers: corsHeaders(origin),
    body: typeof body === 'string' ? body : JSON.stringify(body),
  };
}

function pickOrigin(headers) {
  const origin = (headers && (headers.Origin || headers.origin)) || '';
  const allowed = (process.env.ALLOWED_ORIGIN || '').split(',').map((s) => s.trim()).filter(Boolean);
  if (!origin) return null;
  if (allowed.includes(origin)) return origin;
  return null;
}

async function fetchGistById(gistId) {
  const res = await fetch(`https://api.github.com/gists/${gistId}`, {
    headers: {
      Authorization: `Bearer ${process.env.GITHUB_PAT}`,
      Accept: 'application/vnd.github+json',
      'User-Agent': 'qb-report-relay-scf',
    },
  });
  const text = await res.text();
  if (!res.ok) throw new Error(`Gist GET ${res.status}: ${text.slice(0, 200)}`);
  return JSON.parse(text);
}

async function patchGistFileById(gistId, filename, content) {
  const res = await fetch(`https://api.github.com/gists/${gistId}`, {
    method: 'PATCH',
    headers: {
      Authorization: `Bearer ${process.env.GITHUB_PAT}`,
      Accept: 'application/vnd.github+json',
      'Content-Type': 'application/json',
      'User-Agent': 'qb-report-relay-scf',
    },
    body: JSON.stringify({ files: { [filename]: { content } } }),
  });
  const text = await res.text();
  if (!res.ok) throw new Error(`Gist PATCH ${res.status}: ${text.slice(0, 200)}`);
  return JSON.parse(text);
}

function getFileContent(gist, filename, fallback) {
  const f = gist.files && gist.files[filename];
  if (!f || !f.content) return fallback;
  try { return JSON.parse(f.content); } catch (_) { return fallback; }
}

// ========== 汇报 HTML 评论（透传 gist）==========

async function handleGistRead(origin) {
  try {
    const gist = await fetchGistById(process.env.GIST_ID);
    const files = {};
    for (const [name, file] of Object.entries(gist.files || {})) {
      files[name] = {
        content: file.content,
        truncated: file.truncated,
        raw_url: file.raw_url,
        size: file.size,
      };
    }
    return apigwResponse({ files }, 200, origin || '*');
  } catch (e) {
    return apigwResponse({ error: e.message }, 500, origin || '*');
  }
}

async function handleGistWrite(rawBody, origin) {
  let body;
  try {
    body = typeof rawBody === 'string' ? JSON.parse(rawBody) : rawBody;
  } catch (_) {
    return apigwResponse({ error: 'invalid json' }, 400, origin);
  }
  if (!body || typeof body !== 'object') {
    return apigwResponse({ error: 'invalid body' }, 400, origin);
  }
  if (body.password !== process.env.ACCESS_PASSWORD) {
    return apigwResponse({ error: 'password incorrect' }, 401, origin);
  }
  const nickname = (body.nickname || '').trim();
  if (!nickname || nickname.length > 30) {
    return apigwResponse({ error: 'nickname required (1-30 chars)' }, 400, origin);
  }
  const filename = body.filename;
  if (!ALLOWED_FILES.has(filename)) {
    return apigwResponse({ error: 'filename not allowed' }, 400, origin);
  }
  const content = typeof body.content === 'string' ? body.content : JSON.stringify(body.content);
  if (!content || content.length > MAX_CONTENT_BYTES) {
    return apigwResponse({ error: 'content empty or too large' }, 400, origin);
  }
  try {
    await patchGistFileById(process.env.GIST_ID, filename, content);
    return apigwResponse({ ok: true, filename, by: nickname, time: new Date().toISOString() }, 200, origin);
  } catch (e) {
    return apigwResponse({ error: e.message }, 500, origin);
  }
}

// ========== skills 官网 stats ==========

function ensureStatsConfigured() {
  return !!process.env.STATS_GIST_ID;
}

async function loadStats() {
  const gist = await fetchGistById(process.env.STATS_GIST_ID);
  return getFileContent(gist, STATS_FILENAME, { views: 0, visitors: [], likes: [], comments: [] });
}

async function saveStats(stats) {
  await patchGistFileById(process.env.STATS_GIST_ID, STATS_FILENAME, JSON.stringify(stats, null, 2));
}

function sanitizeNickname(s) {
  return (s || '').toString().trim().slice(0, 30);
}

function publicStats(stats) {
  return {
    views: stats.views || 0,
    likes: (stats.likes || []).map(l => ({ name: l.name || null, time: l.time })),
    comments: (stats.comments || []).map(c => ({
      id: c.id, name: c.name || null, text: c.text, time: c.time,
    })),
  };
}

async function handleStatsRead(origin) {
  if (!ensureStatsConfigured()) return apigwResponse({ error: 'stats not configured' }, 501, origin || '*');
  try {
    const stats = await loadStats();
    return apigwResponse(publicStats(stats), 200, origin || '*');
  } catch (e) {
    return apigwResponse({ error: e.message }, 500, origin || '*');
  }
}

async function handleStatsView(rawBody, origin) {
  if (!ensureStatsConfigured()) return apigwResponse({ error: 'stats not configured' }, 501, origin);
  let body;
  try { body = typeof rawBody === 'string' ? JSON.parse(rawBody) : rawBody; }
  catch (_) { return apigwResponse({ error: 'invalid json' }, 400, origin); }
  const visitorId = (body && body.visitorId || '').toString().slice(0, 64);
  if (!visitorId) return apigwResponse({ error: 'visitorId required' }, 400, origin);
  try {
    const stats = await loadStats();
    stats.visitors = stats.visitors || [];
    if (!stats.visitors.includes(visitorId)) {
      stats.visitors.push(visitorId);
      // 只保留最近 10000 个 visitorId，防止膨胀
      if (stats.visitors.length > 10000) stats.visitors = stats.visitors.slice(-10000);
      stats.views = (stats.views || 0) + 1;
      await saveStats(stats);
    }
    return apigwResponse({ ok: true, views: stats.views }, 200, origin);
  } catch (e) {
    return apigwResponse({ error: e.message }, 500, origin);
  }
}

async function handleStatsLike(rawBody, origin) {
  if (!ensureStatsConfigured()) return apigwResponse({ error: 'stats not configured' }, 501, origin);
  let body;
  try { body = typeof rawBody === 'string' ? JSON.parse(rawBody) : rawBody; }
  catch (_) { return apigwResponse({ error: 'invalid json' }, 400, origin); }
  const visitorId = (body && body.visitorId || '').toString().slice(0, 64);
  if (!visitorId) return apigwResponse({ error: 'visitorId required' }, 400, origin);
  const name = sanitizeNickname(body && body.nickname);
  try {
    const stats = await loadStats();
    stats.likes = stats.likes || [];
    // 一个 visitorId 只能点一次
    if (stats.likes.some(l => l.visitorId === visitorId)) {
      return apigwResponse({ ok: true, already: true, total: stats.likes.length }, 200, origin);
    }
    stats.likes.push({ visitorId, name: name || null, time: Date.now() });
    if (stats.likes.length > 50000) stats.likes = stats.likes.slice(-50000);
    await saveStats(stats);
    return apigwResponse({ ok: true, total: stats.likes.length }, 200, origin);
  } catch (e) {
    return apigwResponse({ error: e.message }, 500, origin);
  }
}

async function handleStatsComment(rawBody, origin) {
  if (!ensureStatsConfigured()) return apigwResponse({ error: 'stats not configured' }, 501, origin);
  let body;
  try { body = typeof rawBody === 'string' ? JSON.parse(rawBody) : rawBody; }
  catch (_) { return apigwResponse({ error: 'invalid json' }, 400, origin); }
  if (body.password !== process.env.ACCESS_PASSWORD) {
    return apigwResponse({ error: 'password incorrect' }, 401, origin);
  }
  const name = sanitizeNickname(body.nickname);
  const text = (body.text || '').toString().trim().slice(0, MAX_TEXT_LEN);
  if (!text) return apigwResponse({ error: 'text required' }, 400, origin);
  try {
    const stats = await loadStats();
    stats.comments = stats.comments || [];
    const newComment = {
      id: 'c_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
      name: name || null,
      text,
      time: Date.now(),
    };
    stats.comments.push(newComment);
    if (stats.comments.length > MAX_COMMENTS) stats.comments = stats.comments.slice(-MAX_COMMENTS);
    await saveStats(stats);
    return apigwResponse({ ok: true, comment: newComment, total: stats.comments.length }, 200, origin);
  } catch (e) {
    return apigwResponse({ error: e.message }, 500, origin);
  }
}

async function handleStatsCommentDelete(rawBody, origin) {
  if (!ensureStatsConfigured()) return apigwResponse({ error: 'stats not configured' }, 501, origin);
  let body;
  try { body = typeof rawBody === 'string' ? JSON.parse(rawBody) : rawBody; }
  catch (_) { return apigwResponse({ error: 'invalid json' }, 400, origin); }
  if (body.password !== process.env.ACCESS_PASSWORD) {
    return apigwResponse({ error: 'password incorrect' }, 401, origin);
  }
  const ids = Array.isArray(body.ids) ? body.ids : (body.id ? [body.id] : []);
  if (!ids.length) return apigwResponse({ error: 'ids required' }, 400, origin);
  try {
    const stats = await loadStats();
    stats.comments = (stats.comments || []).filter(c => !ids.includes(c.id));
    await saveStats(stats);
    return apigwResponse({ ok: true, total: stats.comments.length }, 200, origin);
  } catch (e) {
    return apigwResponse({ error: e.message }, 500, origin);
  }
}

// ========== 入口 ==========

exports.main_handler = async (event, context) => {
  const method = (event.httpMethod || event.method || 'GET').toUpperCase();
  let path = event.path || (event.requestContext && event.requestContext.path) || '/';
  const headers = event.headers || {};
  const origin = pickOrigin(headers);

  const segments = path.split('/').filter(Boolean);
  // 去掉可能的环境前缀（如 /release），取末尾 1-3 段
  const tail = segments.slice(-3);
  const tailPath = '/' + tail.join('/');
  const tail2 = segments.slice(-2);
  const tail2Path = '/' + tail2.join('/');
  const tail1 = segments.slice(-1);
  const tail1Path = '/' + (tail1[0] || '');

  const matches = (p) => tailPath === p || tail2Path === p || tail1Path === p;

  if (method === 'OPTIONS') {
    return {
      isBase64Encoded: false,
      statusCode: 204,
      headers: corsHeaders(origin || '*'),
      body: '',
    };
  }

  // 健康检查
  if (method === 'GET' && (matches('/health') || matches('/'))) {
    return apigwResponse({
      ok: true,
      name: 'qb-report-relay',
      runtime: 'tencent-scf',
      version: 'v2.0',
      features: {
        gist_relay: !!process.env.GIST_ID,
        stats: !!process.env.STATS_GIST_ID,
      },
    }, 200, origin || '*');
  }

  // 汇报评论
  if (method === 'GET' && matches('/gist')) {
    return handleGistRead(origin);
  }
  if (method === 'POST' && matches('/gist/file')) {
    if (!origin) return apigwResponse({ error: 'origin not allowed' }, 403, '*');
    return handleGistWrite(event.body, origin);
  }

  // skills 官网 stats
  if (method === 'GET' && matches('/stats')) {
    return handleStatsRead(origin);
  }
  if (method === 'POST' && matches('/stats/view')) {
    if (!origin) return apigwResponse({ error: 'origin not allowed' }, 403, '*');
    return handleStatsView(event.body, origin);
  }
  if (method === 'POST' && matches('/stats/like')) {
    if (!origin) return apigwResponse({ error: 'origin not allowed' }, 403, '*');
    return handleStatsLike(event.body, origin);
  }
  if (method === 'POST' && matches('/stats/comment')) {
    if (!origin) return apigwResponse({ error: 'origin not allowed' }, 403, '*');
    return handleStatsComment(event.body, origin);
  }
  if (method === 'POST' && (matches('/stats/comment/delete') || tailPath === '/stats/comment/delete')) {
    if (!origin) return apigwResponse({ error: 'origin not allowed' }, 403, '*');
    return handleStatsCommentDelete(event.body, origin);
  }

  return apigwResponse({ error: 'not found', path, method }, 404, origin || '*');
};
