#!/usr/bin/env python3
"""
HTML 评论注入 (v2.0 - SCF 版)
用法：
    python3 inject.py <html_file>

做的事：
1. 读 config.json 拿到 SCF URL / pages origin / 密码提示
2. 把 snippets/comments.css 和 snippets/comments.js 注入到目标 HTML
3. 替换 __SCF_URL__ / __PAGES_ORIGIN__ / __PASSWORD_HINT__ 占位符
4. 在 <body> 末尾加 <div id="qbc-comments"></div> + 初始化调用（如果目标 HTML 没有手动标记位置）

如果目标 HTML 里有 <!-- QBC_COMMENTS --> 注释，会在那里插入 container（推荐）。
"""

import sys
import os
import json
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent
CONFIG = HERE / 'config.json'
CSS = HERE / 'snippets' / 'comments.css'
JS = HERE / 'snippets' / 'comments.js'


def load_config():
    with open(CONFIG, 'r', encoding='utf-8') as f:
        return json.load(f)


def main():
    if len(sys.argv) < 2:
        print(f"用法：python3 {sys.argv[0]} <html_file>")
        sys.exit(1)
    html_path = Path(sys.argv[1]).resolve()
    if not html_path.exists():
        print(f"文件不存在：{html_path}")
        sys.exit(1)

    config = load_config()
    scf_url = config.get('scf_url', '').rstrip('/')
    pages_origin = config.get('pages_origin', '').rstrip('/')
    password_hint = config.get('password_hint') or f"密码：{config.get('access_password', '（作者未告知）')}"

    if not scf_url:
        print("❌ config.json 里 scf_url 为空，先部署 SCF 再配置")
        sys.exit(1)

    with open(CSS, 'r', encoding='utf-8') as f:
        css = f.read()
    with open(JS, 'r', encoding='utf-8') as f:
        js = f.read()

    js = js.replace('__SCF_URL__', scf_url)
    js = js.replace('__PAGES_ORIGIN__', pages_origin)
    js = js.replace('__PASSWORD_HINT__', password_hint)

    with open(html_path, 'r', encoding='utf-8') as f:
        html = f.read()

    # 幂等：如果已注入过，替换
    css_marker_begin = '<!-- QBC_CSS_BEGIN -->'
    css_marker_end = '<!-- QBC_CSS_END -->'
    js_marker_begin = '<!-- QBC_JS_BEGIN -->'
    js_marker_end = '<!-- QBC_JS_END -->'

    css_block = f'{css_marker_begin}\n<style>\n{css}\n</style>\n{css_marker_end}'
    js_block = f'{js_marker_begin}\n<script>\n{js}\n</script>\n{js_marker_end}'

    def replace_or_insert(html, marker_begin, marker_end, block, before_tag):
        pattern = re.compile(re.escape(marker_begin) + r'[\s\S]*?' + re.escape(marker_end))
        if pattern.search(html):
            return pattern.sub(block, html)
        # 在指定标签前插入
        idx = html.rfind(before_tag)
        if idx < 0:
            return html + '\n' + block + '\n'
        return html[:idx] + block + '\n' + html[idx:]

    html = replace_or_insert(html, css_marker_begin, css_marker_end, css_block, '</head>')
    html = replace_or_insert(html, js_marker_begin, js_marker_end, js_block, '</body>')

    # 检查是否有 QBC_COMMENTS 占位
    placeholder = '<!-- QBC_COMMENTS -->'
    init_call = '\n<div id="qbc-comments"></div>\n<script>document.addEventListener("DOMContentLoaded", () => commentsInit("#qbc-comments"));</script>\n'
    if placeholder in html:
        html = html.replace(placeholder, init_call)
    elif 'id="qbc-comments"' not in html:
        # 没有就在 </body> 前添加
        if '</body>' in html:
            html = html.replace('</body>', init_call + '</body>', 1)
        else:
            html += init_call

    with open(html_path, 'w', encoding='utf-8') as f:
        f.write(html)

    print(f"✅ 已注入评论模块到：{html_path}")
    print(f"   SCF endpoint: {scf_url}")
    print(f"   Pages origin: {pages_origin}")
    print(f"   密码提示: {password_hint}")
    print("")
    print("下一步：用 html-deploy-github 部署上线：")
    print(f"   python3 ~/.workbuddy/skills/html-deploy-github/scripts/deploy.py {html_path} --repo <your_repo>")


if __name__ == '__main__':
    main()
