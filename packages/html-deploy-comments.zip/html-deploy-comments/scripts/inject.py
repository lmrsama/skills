#!/usr/bin/env python3
"""
往本地 HTML 文件里注入评论模块（CSS + JS + Gist 配置）

用法：
    python3 inject.py <html_path>                   # 原地注入（备份原文件为 .bak）
    python3 inject.py <html_path> -o <out_path>     # 输出到新文件
    python3 inject.py --setup-gist                  # 创建专用 comments gist 并写入配置
    python3 inject.py --check                       # 检查配置完整性

需要的配置（首次注入前自动检查）：
- ~/.workbuddy/skills/.shared/github.json  · github_token + github_user（来自 html-deploy-github）
- ~/.workbuddy/skills/html-deploy-comments/config.json · gist_id

如果没有 gist，运行 --setup-gist 自动创建。
"""
import sys
import os
import re
import json
import argparse
import urllib.request
import urllib.error
from pathlib import Path

SHARED_GH = Path.home() / '.workbuddy' / 'skills' / '.shared' / 'github.json'
SKILL_DIR = Path(__file__).resolve().parent.parent
CFG_PATH = SKILL_DIR / 'config.json'
CSS_PATH = SKILL_DIR / 'snippets' / 'comments.css'
JS_PATH = SKILL_DIR / 'snippets' / 'comments.js'


# ============ 配置 ============
def load_gh():
    if not SHARED_GH.exists():
        print('✗ 缺共享配置：' + str(SHARED_GH))
        print('  请先运行 html-deploy-github 的 setup.py')
        sys.exit(1)
    return json.loads(SHARED_GH.read_text(encoding='utf-8'))


def load_cfg():
    if not CFG_PATH.exists():
        return {}
    try:
        return json.loads(CFG_PATH.read_text(encoding='utf-8'))
    except Exception:
        return {}


def save_cfg(cfg):
    CFG_PATH.write_text(json.dumps(cfg, indent=2, ensure_ascii=False), encoding='utf-8')
    os.chmod(CFG_PATH, 0o600)


# ============ Gist 自动创建 ============
def github_api(method, path, token, body=None):
    url = 'https://api.github.com' + path
    data = json.dumps(body).encode('utf-8') if body else None
    req = urllib.request.Request(url, data=data, method=method, headers={
        'Authorization': 'token ' + token,
        'Accept': 'application/vnd.github+json',
        'Content-Type': 'application/json',
    })
    try:
        res = urllib.request.urlopen(req, timeout=20)
        body_bytes = res.read()
        return res.getcode(), json.loads(body_bytes) if body_bytes else None
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read())
        except Exception:
            return e.code, None


def setup_gist():
    gh = load_gh()
    token = gh['github_token']
    cfg = load_cfg()

    if cfg.get('gist_id'):
        print(f'已存在 gist_id: {cfg["gist_id"]}')
        ans = input('重新创建? [y/N]: ').strip().lower()
        if ans != 'y':
            return

    print('▸ 创建评论 Gist...')
    code, data = github_api('POST', '/gists', token, {
        'description': 'WorkBuddy comments storage',
        'public': True,  # public 不影响隐私（写还是要 token），便于通过 raw_url fallback
        'files': {'comments.json': {'content': '[]'}}
    })
    if code >= 300:
        print(f'✗ 创建失败 {code}: {data}')
        sys.exit(1)
    gist_id = data['id']
    cfg['gist_id'] = gist_id
    save_cfg(cfg)
    print(f'  ✓ gist_id: {gist_id}')
    print(f'  写入：{CFG_PATH}')


def check():
    gh = load_gh()
    cfg = load_cfg()
    print('GitHub token  :', '✓' if gh.get('github_token') else '✗')
    print('GitHub user   :', gh.get('github_user') or '✗')
    print('Comments gist :', cfg.get('gist_id') or '✗（运行 --setup-gist）')
    if cfg.get('gist_id'):
        code, data = github_api('GET', '/gists/' + cfg['gist_id'], gh['github_token'])
        print('Gist reachable:', '✓' if code == 200 else f'✗ ({code})')


# ============ HTML 注入 ============
TOOLBAR_PADDING_HINT = '<!-- hdc-comments-injected -->'


def already_injected(html):
    return TOOLBAR_PADDING_HINT in html


def inject_html(html, gist_id, token):
    if already_injected(html):
        # 替换占位符即可（重复注入不重复加 CSS/JS）
        html = re.sub(r"const GIST_ID = '[^']*';", f"const GIST_ID = '{gist_id}';", html, count=1)
        html = re.sub(r"const TOKEN = '[^']*';", f"const TOKEN = '{token}';", html, count=1)
        # 兼容首次注入用的占位符
        html = html.replace('__HDC_GIST_ID__', gist_id).replace('__HDC_TOKEN__', token)
        return html, 'updated'

    css = CSS_PATH.read_text(encoding='utf-8')
    js = JS_PATH.read_text(encoding='utf-8')
    js = js.replace('__HDC_GIST_ID__', gist_id).replace('__HDC_TOKEN__', token)

    css_block = f'\n<style>\n/* hdc-comments-css */\n{css}\n</style>\n'
    js_block = f'\n<script>\n/* hdc-comments-js */\n{js}\n</script>\n{TOOLBAR_PADDING_HINT}\n'

    # 注入到 </head> 之前
    if '</head>' in html:
        html = html.replace('</head>', css_block + '</head>', 1)
    else:
        html = css_block + html

    # 注入到 </body> 之前
    if '</body>' in html:
        html = html.replace('</body>', js_block + '</body>', 1)
    else:
        html = html + js_block

    return html, 'injected'


def cmd_inject(html_path, out_path):
    gh = load_gh()
    cfg = load_cfg()
    if not cfg.get('gist_id'):
        print('✗ 未配置 gist_id，请先运行：python3 inject.py --setup-gist')
        sys.exit(1)

    html_path = Path(html_path)
    if not html_path.exists():
        print(f'✗ 文件不存在：{html_path}')
        sys.exit(1)

    html = html_path.read_text(encoding='utf-8')
    new_html, action = inject_html(html, cfg['gist_id'], gh['github_token'])

    if not out_path:
        # 原地替换，先备份
        bak = html_path.with_suffix(html_path.suffix + '.bak')
        if not bak.exists():
            bak.write_text(html, encoding='utf-8')
            print(f'  备份：{bak}')
        target = html_path
    else:
        target = Path(out_path)

    target.write_text(new_html, encoding='utf-8')
    print(f'  ✓ {action}: {target}')
    print(f'  size: {len(new_html):,} bytes')
    print()
    print('下一步：用 html-deploy-github 部署')
    print(f'  python3 ~/.workbuddy/skills/html-deploy-github/scripts/deploy.py {target} --repo <name>')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('html_path', nargs='?', help='本地 HTML 文件路径')
    ap.add_argument('-o', '--output', help='输出到新文件（不传则原地修改并备份）')
    ap.add_argument('--setup-gist', action='store_true', help='创建专用评论 Gist 并写入配置')
    ap.add_argument('--check', action='store_true', help='检查配置完整性')
    args = ap.parse_args()

    if args.setup_gist:
        setup_gist()
        return
    if args.check:
        check()
        return
    if not args.html_path:
        ap.print_help()
        sys.exit(1)
    cmd_inject(args.html_path, args.output)


if __name__ == '__main__':
    main()
