/* ==========================================================================
   html-deploy-comments · 评论模块 JS
   注入到任意 HTML </body> 之前。
   占位符（部署时替换）：
     __HDC_GIST_ID__   ← Gist ID
     __HDC_TOKEN__     ← GitHub PAT（直接明文嵌入；仓库 public 即等同公开，仅作 Gist 写权限）
                          注意：comments skill 只需要 Gist 写权限，不需要加密；
                          如果担心 token 被滥用，请用单独的 fine-grained PAT 仅授权 Gist
   ========================================================================== */
(function () {
  'use strict';

  const GIST_ID = '__HDC_GIST_ID__';
  const TOKEN = '__HDC_TOKEN__';
  const FILENAME = 'comments.json';

  // ---- 状态 ----
  const state = {
    mode: 'view',          // 'view' | 'comment'
    comments: [],          // [{id, target, text, author, time}]
    selected: null,        // 当前选中的 commentable 元素
    panelOpen: false,
    author: localStorage.getItem('hdc-author') || '',
  };

  // ---- 工具 ----
  const $ = (sel, ctx) => (ctx || document).querySelector(sel);
  const $$ = (sel, ctx) => Array.from((ctx || document).querySelectorAll(sel));
  const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  const fmtTime = (ts) => {
    const d = new Date(ts); const now = Date.now();
    const diff = now - ts;
    if (diff < 60000) return '刚刚';
    if (diff < 3600000) return Math.floor(diff / 60000) + ' 分钟前';
    if (diff < 86400000) return Math.floor(diff / 3600000) + ' 小时前';
    return d.getMonth() + 1 + '/' + d.getDate() + ' ' + String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
  };
  const escHtml = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  // ---- Toast ----
  let toastEl = null;
  function toast(msg, ms) {
    if (!toastEl) {
      toastEl = document.createElement('div');
      toastEl.className = 'hdc-toast';
      document.body.appendChild(toastEl);
    }
    toastEl.textContent = msg;
    toastEl.classList.add('hdc-show');
    clearTimeout(toastEl._t);
    toastEl._t = setTimeout(() => toastEl.classList.remove('hdc-show'), ms || 2000);
  }

  // ---- 名字弹窗 ----
  function askAuthor() {
    return new Promise((resolve) => {
      const mask = document.createElement('div');
      mask.className = 'hdc-modal-mask hdc-open';
      mask.innerHTML = `
        <div class="hdc-modal">
          <h3>怎么称呼你？</h3>
          <p>评论时会显示这个名字（仅本设备记住）</p>
          <input type="text" placeholder="例如：李总、产品张三" maxlength="20" />
          <div class="hdc-modal-actions">
            <button class="hdc-cancel">取消</button>
            <button class="hdc-primary">确定</button>
          </div>
        </div>`;
      document.body.appendChild(mask);
      const input = mask.querySelector('input');
      input.value = state.author || '';
      input.focus();
      const cleanup = () => mask.remove();
      mask.querySelector('.hdc-cancel').onclick = () => { cleanup(); resolve(null); };
      mask.querySelector('.hdc-primary').onclick = () => {
        const v = input.value.trim();
        if (!v) { input.focus(); return; }
        state.author = v;
        localStorage.setItem('hdc-author', v);
        cleanup();
        resolve(v);
      };
      input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') mask.querySelector('.hdc-primary').click();
      });
    });
  }

  // ---- Gist API ----
  async function gistFetch() {
    try {
      const r = await fetch('https://api.github.com/gists/' + GIST_ID, {
        headers: { 'Authorization': 'token ' + TOKEN, 'Accept': 'application/vnd.github+json' }
      });
      if (!r.ok) { console.warn('hdc gist fetch failed', r.status); return []; }
      const data = await r.json();
      const file = data.files && data.files[FILENAME];
      if (!file) return [];
      let content = file.content;
      if (file.truncated && file.raw_url) {
        const r2 = await fetch(file.raw_url);
        if (r2.ok) content = await r2.text();
      }
      try {
        const parsed = JSON.parse(content);
        return Array.isArray(parsed) ? parsed : [];
      } catch (_) { return []; }
    } catch (e) {
      console.warn('hdc gist fetch error', e);
      return [];
    }
  }

  async function gistSave(comments) {
    try {
      const body = { files: {} };
      body.files[FILENAME] = { content: JSON.stringify(comments, null, 2) };
      const r = await fetch('https://api.github.com/gists/' + GIST_ID, {
        method: 'PATCH',
        headers: { 'Authorization': 'token ' + TOKEN, 'Accept': 'application/vnd.github+json', 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      if (!r.ok) { console.error('hdc gist save', r.status); return false; }
      return true;
    } catch (e) { console.error('hdc gist save', e); return false; }
  }

  // ---- 元素定位 ----
  // commentable 选择策略：data-section 优先，否则用 querySelector 路径
  function getTargetKey(el) {
    if (el.dataset.section) return 'section:' + el.dataset.section;
    // 退路：用 tag + nth-child path
    const path = [];
    let cur = el;
    while (cur && cur !== document.body && path.length < 6) {
      const idx = Array.from(cur.parentNode ? cur.parentNode.children : []).indexOf(cur);
      path.unshift(cur.tagName.toLowerCase() + (idx >= 0 ? ':nth-child(' + (idx + 1) + ')' : ''));
      cur = cur.parentNode;
    }
    return 'path:' + path.join('>');
  }

  function findByKey(key) {
    if (key.startsWith('section:')) {
      return $('[data-section="' + key.slice(8) + '"]');
    }
    if (key.startsWith('path:')) {
      try { return document.querySelector(key.slice(5)); } catch (_) { return null; }
    }
    return null;
  }

  // ---- 渲染 ----
  function renderBadges() {
    const counts = {};
    state.comments.forEach((c) => { counts[c.target] = (counts[c.target] || 0) + 1; });
    $$('.hdc-commentable').forEach((el) => {
      const key = getTargetKey(el);
      if (counts[key]) {
        el.classList.add('hdc-has-comments');
        el.dataset.hdcCount = counts[key];
      } else {
        el.classList.remove('hdc-has-comments');
        delete el.dataset.hdcCount;
      }
    });
    $('.hdc-status').textContent = state.comments.length ? state.comments.length + ' 条评论' : '暂无评论';
  }

  function renderPanel() {
    const body = $('.hdc-panel-body');
    if (!state.comments.length) {
      body.innerHTML = '<div class="hdc-empty">还没有评论<br>切换到「批注」模式后点击元素留言</div>';
      return;
    }
    const sorted = state.comments.slice().sort((a, b) => b.time - a.time);
    body.innerHTML = sorted.map((c) => {
      const targetEl = findByKey(c.target);
      const targetLabel = targetEl ? (targetEl.dataset.section || targetEl.tagName.toLowerCase()) : '已删除元素';
      return `
        <div class="hdc-comment-item" data-id="${c.id}">
          <div class="hdc-comment-meta">
            <strong>${escHtml(c.author)}</strong>
            <span>${fmtTime(c.time)}</span>
          </div>
          <div class="hdc-comment-target" data-target="${escHtml(c.target)}">📍 ${escHtml(targetLabel)}</div>
          <div class="hdc-comment-text">${escHtml(c.text)}</div>
          <div class="hdc-comment-actions">
            ${c.author === state.author ? `<a class="hdc-del" data-id="${c.id}">删除</a>` : ''}
          </div>
        </div>`;
    }).join('');
  }

  // ---- 事件 ----
  function setMode(mode) {
    state.mode = mode;
    document.body.classList.toggle('hdc-mode-comment', mode === 'comment');
    document.body.classList.toggle('hdc-mode-view', mode === 'view');
    $('.hdc-btn-mode-view').classList.toggle('active', mode === 'view');
    $('.hdc-btn-mode-comment').classList.toggle('active', mode === 'comment');
    if (mode !== 'comment') clearSelection();
  }

  function clearSelection() {
    if (state.selected) state.selected.classList.remove('hdc-selected');
    state.selected = null;
    const bub = $('.hdc-bubble');
    if (bub) bub.remove();
  }

  function selectElement(el) {
    clearSelection();
    state.selected = el;
    el.classList.add('hdc-selected');
    showBubble(el);
  }

  function showBubble(el) {
    const rect = el.getBoundingClientRect();
    const bub = document.createElement('div');
    bub.className = 'hdc-bubble';
    bub.textContent = '💬 评论这里';
    document.body.appendChild(bub);
    const top = window.scrollY + rect.top - 36;
    const left = window.scrollX + rect.left;
    bub.style.top = Math.max(window.scrollY + 56, top) + 'px';
    bub.style.left = left + 'px';
    bub.onclick = (e) => {
      e.stopPropagation();
      openPanelForWrite();
    };
  }

  async function openPanelForWrite() {
    if (!state.author) {
      const a = await askAuthor();
      if (!a) return;
    }
    openPanel();
    const ta = $('.hdc-panel-footer textarea');
    ta.focus();
  }

  function openPanel() {
    state.panelOpen = true;
    $('.hdc-panel').classList.add('hdc-open');
    renderPanel();
  }

  function closePanel() {
    state.panelOpen = false;
    $('.hdc-panel').classList.remove('hdc-open');
  }

  async function submitComment() {
    const ta = $('.hdc-panel-footer textarea');
    const text = ta.value.trim();
    if (!text) return;
    if (!state.selected) {
      toast('请先在页面上点选要评论的位置');
      return;
    }
    if (!state.author) {
      const a = await askAuthor();
      if (!a) return;
    }
    const c = {
      id: uid(),
      target: getTargetKey(state.selected),
      text,
      author: state.author,
      time: Date.now(),
    };
    state.comments.push(c);
    renderBadges();
    renderPanel();
    ta.value = '';
    toast('已发布');
    const ok = await gistSave(state.comments);
    if (!ok) toast('云端保存失败，将在下次发布时重试');
  }

  async function deleteComment(id) {
    state.comments = state.comments.filter((c) => c.id !== id);
    renderBadges();
    renderPanel();
    await gistSave(state.comments);
    toast('已删除');
  }

  function exportMarkdown() {
    if (!state.comments.length) { toast('暂无评论'); return; }
    const lines = ['# 评论汇总', '', `导出时间：${new Date().toLocaleString()}`, `共 ${state.comments.length} 条`, ''];
    const sorted = state.comments.slice().sort((a, b) => a.time - b.time);
    sorted.forEach((c, i) => {
      const el = findByKey(c.target);
      const target = el ? (el.dataset.section || el.tagName.toLowerCase()) : '已删除';
      lines.push(`## ${i + 1}. ${c.author} · ${new Date(c.time).toLocaleString()}`);
      lines.push(`> 📍 位置：${target}`);
      lines.push('');
      lines.push(c.text);
      lines.push('');
    });
    const blob = new Blob([lines.join('\n')], { type: 'text/markdown' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'comments-' + new Date().toISOString().slice(0, 10) + '.md';
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  }

  // ---- 注入 UI ----
  function injectUI() {
    document.body.classList.add('hdc-has-toolbar');

    const toolbar = document.createElement('div');
    toolbar.className = 'hdc-toolbar';
    toolbar.innerHTML = `
      <strong style="font-size:13px;">📝 在线评审</strong>
      <button class="hdc-btn-mode-view active" title="只读模式">👁️ 只读</button>
      <button class="hdc-btn-mode-comment" title="批注模式：点元素留言">💬 批注</button>
      <span class="hdc-spacer"></span>
      <span class="hdc-status">加载中...</span>
      <button class="hdc-btn-panel" title="查看所有评论">📋 评论列表</button>
      <button class="hdc-btn-export" title="导出 Markdown">📤 导出</button>
    `;
    document.body.appendChild(toolbar);

    const panel = document.createElement('aside');
    panel.className = 'hdc-panel';
    panel.innerHTML = `
      <div class="hdc-panel-header">
        <strong>评论</strong>
        <button class="hdc-panel-close">✕</button>
      </div>
      <div class="hdc-panel-body"></div>
      <div class="hdc-panel-footer">
        <textarea placeholder="输入评论...（先点页面元素选位置）" rows="2"></textarea>
        <button class="hdc-submit">发布</button>
      </div>
    `;
    document.body.appendChild(panel);

    // 事件绑定
    $('.hdc-btn-mode-view').onclick = () => setMode('view');
    $('.hdc-btn-mode-comment').onclick = () => setMode('comment');
    $('.hdc-btn-panel').onclick = () => state.panelOpen ? closePanel() : openPanel();
    $('.hdc-btn-export').onclick = exportMarkdown;
    $('.hdc-panel-close').onclick = closePanel;
    $('.hdc-submit').onclick = submitComment;

    // 点击 commentable
    document.addEventListener('click', (e) => {
      if (state.mode !== 'comment') return;
      if (e.target.closest('.hdc-toolbar') || e.target.closest('.hdc-panel') || e.target.closest('.hdc-bubble') || e.target.closest('.hdc-modal-mask')) return;
      const target = e.target.closest('.hdc-commentable');
      if (target) {
        e.preventDefault();
        e.stopPropagation();
        selectElement(target);
      } else {
        clearSelection();
      }
    }, true);

    // 评论项跳转 / 删除
    panel.addEventListener('click', (e) => {
      const tgt = e.target.closest('.hdc-comment-target');
      if (tgt) {
        const el = findByKey(tgt.dataset.target);
        if (el) {
          el.scrollIntoView({ behavior: 'smooth', block: 'center' });
          el.classList.add('hdc-selected');
          setTimeout(() => el.classList.remove('hdc-selected'), 1500);
        } else {
          toast('该元素已删除');
        }
        return;
      }
      const del = e.target.closest('.hdc-del');
      if (del && confirm('删除这条评论？')) {
        deleteComment(del.dataset.id);
      }
    });

    // 滚动时跟随气泡
    window.addEventListener('scroll', () => {
      if (state.selected) {
        const bub = $('.hdc-bubble');
        if (bub) showBubble(state.selected);
      }
    }, { passive: true });

    // textarea Enter 不提交（用 Shift+Enter 才换行也太麻烦——直接允许 Enter 换行，按钮提交）
    $('.hdc-panel-footer textarea').addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        submitComment();
      }
    });
  }

  // ---- 自动给"显眼区块"加 commentable class ----
  // 策略：默认所有 .container > 直接子元素（h1/h2/h3/section/div/p）都可评论
  // 用户可以手动改 HTML 加 .hdc-commentable 自定义粒度
  function autoMarkCommentable() {
    if ($$('.hdc-commentable').length) return;  // 用户已手动标注
    const candidates = $$('.container > *, main > *, article > *, body > section, body > div > *');
    let count = 0;
    candidates.forEach((el) => {
      if (el.closest('.hdc-toolbar') || el.closest('.hdc-panel')) return;
      if (el.tagName === 'SCRIPT' || el.tagName === 'STYLE') return;
      // 文字太少的 span/em 跳过
      if (el.textContent.trim().length < 4 && !el.querySelector('img,svg,canvas')) return;
      el.classList.add('hdc-commentable');
      count++;
    });
    console.log('[hdc] auto-marked', count, 'commentable elements');
  }

  // ---- 启动 ----
  async function init() {
    autoMarkCommentable();
    injectUI();
    state.comments = await gistFetch();
    renderBadges();
    setMode('view');
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
