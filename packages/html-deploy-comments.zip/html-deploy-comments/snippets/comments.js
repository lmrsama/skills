/**
 * HTML 评论模块 - 前端逻辑 (v2.0 - SCF 版)
 *
 * 依赖占位符（部署时由 inject.py 替换）：
 *   __SCF_URL__         如 https://xxx.ap-guangzhou.tencentscf.com
 *   __PAGES_ORIGIN__    如 https://lmrsama.github.io（用于 CORS hint）
 *   __PASSWORD_HINT__   密码提示语，访客看到
 *
 * 暴露的 API：
 *   commentsInit(containerEl)   - 初始化评论区
 *   commentsAddComment(text)    - 程序化发评论
 *
 * 数据结构：gist comments.json
 *   { "all": [{ id, author, text, time, resolved? }] }
 */

(function() {
  const SCF_URL = '__SCF_URL__';
  const PAGES_ORIGIN = '__PAGES_ORIGIN__';
  const PASSWORD_HINT = '__PASSWORD_HINT__';
  const COMMENTS_FILENAME = 'comments.json';
  const LS_NICKNAME = 'qbc_nickname';
  const SS_PASSWORD = 'qbc_password';
  const POLL_INTERVAL = 30000;

  // ======= 基础弹窗 =======
  function modal(innerHtml) {
    const existing = document.querySelector('.qbc-modal-wrap');
    if (existing) existing.remove();
    const wrap = document.createElement('div');
    wrap.className = 'qbc-modal-wrap';
    wrap.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.55);z-index:999999;display:flex;align-items:center;justify-content:center;backdrop-filter:blur(3px);';
    wrap.innerHTML = `<div class="qbc-modal" style="background:white;border-radius:12px;padding:22px 24px;width:360px;max-width:92vw;box-shadow:0 12px 36px rgba(0,0,0,0.3);">${innerHtml}</div>`;
    document.body.appendChild(wrap);
    wrap.addEventListener('click', e => e.stopPropagation());
    return wrap;
  }

  function askInput(title, hint, placeholder, type) {
    return new Promise(resolve => {
      const wrap = modal(`
        <div style="font-size:15px;font-weight:700;color:#1f2937;margin-bottom:6px;">${title}</div>
        <div style="font-size:12px;color:#888;margin-bottom:14px;">${hint || ''}</div>
        <input class="qbc-input" type="${type || 'text'}" autocomplete="off" placeholder="${placeholder || ''}" style="width:100%;padding:10px 12px;border:1.5px solid #e0e0e0;border-radius:6px;font-size:13px;outline:none;box-sizing:border-box;" />
        <div style="display:flex;gap:10px;margin-top:14px;justify-content:flex-end;">
          <button class="qbc-cancel" style="padding:8px 16px;border:1px solid #e0e0e0;background:white;border-radius:6px;font-size:12px;cursor:pointer;color:#666;">取消</button>
          <button class="qbc-ok" style="padding:8px 18px;border:none;background:#667eea;color:white;border-radius:6px;font-size:12px;font-weight:600;cursor:pointer;">确定</button>
        </div>
      `);
      const input = wrap.querySelector('.qbc-input');
      setTimeout(() => input.focus(), 50);
      const close = (val) => { wrap.remove(); resolve(val); };
      wrap.querySelector('.qbc-ok').onclick = e => { e.preventDefault(); e.stopPropagation(); close(input.value); };
      wrap.querySelector('.qbc-cancel').onclick = e => { e.preventDefault(); e.stopPropagation(); close(null); };
      input.addEventListener('keydown', e => {
        if (e.key === 'Enter') { e.preventDefault(); close(input.value); }
        else if (e.key === 'Escape') { e.preventDefault(); close(null); }
      });
    });
  }

  async function ensureNickname() {
    let name = localStorage.getItem(LS_NICKNAME) || '';
    if (name) return name;
    name = await askInput('👋 请输入昵称', '昵称会显示在评论里（仅本机记忆）', '如：汉博');
    if (!name || !name.trim()) return null;
    name = name.trim().slice(0, 30);
    localStorage.setItem(LS_NICKNAME, name);
    return name;
  }

  async function ensurePassword(force) {
    let pwd = sessionStorage.getItem(SS_PASSWORD);
    if (pwd && !force) return pwd;
    pwd = await askInput('🔒 需要写权限密码', PASSWORD_HINT || '请向页面作者索取密码', '', 'password');
    if (!pwd) return null;
    sessionStorage.setItem(SS_PASSWORD, pwd);
    return pwd;
  }

  // ======= Toast =======
  function toast(msg, ms) {
    const existing = document.querySelector('.qbc-toast');
    if (existing) existing.remove();
    const t = document.createElement('div');
    t.className = 'qbc-toast';
    t.style.cssText = 'position:fixed;top:20px;left:50%;transform:translateX(-50%);background:rgba(0,0,0,0.85);color:white;padding:10px 18px;border-radius:8px;font-size:13px;z-index:1000000;box-shadow:0 4px 16px rgba(0,0,0,0.3);';
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(() => t.remove(), ms || 2500);
  }

  // ======= SCF 读写 =======
  async function gistRead() {
    const res = await fetch(`${SCF_URL}/gist`);
    if (!res.ok) throw new Error('read failed ' + res.status);
    return await res.json();
  }

  async function gistWrite(filename, content) {
    const nickname = await ensureNickname();
    if (!nickname) throw new Error('cancelled');
    let pwd = await ensurePassword(false);
    if (!pwd) throw new Error('cancelled');
    const doFetch = async (password) => fetch(`${SCF_URL}/gist/file`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ password, nickname, filename, content: typeof content === 'string' ? content : JSON.stringify(content) }),
    });
    let res = await doFetch(pwd);
    if (res.status === 401) {
      sessionStorage.removeItem(SS_PASSWORD);
      pwd = await ensurePassword(true);
      if (!pwd) throw new Error('cancelled');
      res = await doFetch(pwd);
    }
    if (!res.ok) {
      const txt = await res.text().catch(() => '');
      throw new Error(`write failed ${res.status}: ${txt.slice(0, 120)}`);
    }
    return await res.json();
  }

  async function loadComments() {
    try {
      const data = await gistRead();
      const file = data.files && data.files[COMMENTS_FILENAME];
      if (!file) return [];
      let content = file.content;
      if (file.truncated && file.raw_url) {
        const r2 = await fetch(file.raw_url);
        if (r2.ok) content = await r2.text();
      }
      const parsed = JSON.parse(content || '{}');
      return Array.isArray(parsed.all) ? parsed.all : [];
    } catch (e) {
      console.warn('[qbc] load', e);
      return [];
    }
  }

  async function saveComments(list) {
    return gistWrite(COMMENTS_FILENAME, { all: list });
  }

  // ======= 渲染 =======
  let _comments = [];
  function renderCommentsList(listEl) {
    if (!_comments.length) {
      listEl.innerHTML = '<div class="qbc-empty">还没有评论，第一个就是你 ✨</div>';
      return;
    }
    const sorted = _comments.slice().sort((a, b) => (b.time || 0) - (a.time || 0));
    listEl.innerHTML = sorted.map(c => `
      <div class="qbc-item">
        <header>
          <div class="qbc-avatar ${!c.author ? 'anon' : ''}">${(c.author || '匿').slice(0, 1)}</div>
          <div class="qbc-meta">
            <strong>${escapeHtml(c.author || '匿名访客')}</strong>
            <time>${fmtTime(c.time)}</time>
          </div>
        </header>
        <div class="qbc-text">${escapeHtml(c.text)}</div>
      </div>
    `).join('');
  }
  function escapeHtml(s) {
    return (s || '').toString().replace(/[&<>"']/g, m => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
    }[m]));
  }
  function fmtTime(ts) {
    if (!ts) return '';
    const t = typeof ts === 'number' ? ts : Date.parse(ts);
    if (isNaN(t)) return ts;
    const d = new Date(t);
    const now = Date.now();
    const diff = now - t;
    if (diff < 60000) return '刚刚';
    if (diff < 3600000) return Math.floor(diff / 60000) + '分钟前';
    if (diff < 86400000) return Math.floor(diff / 3600000) + '小时前';
    return d.toLocaleDateString('zh-CN') + ' ' + d.toTimeString().slice(0, 5);
  }

  // ======= 初始化 =======
  async function commentsInit(root) {
    if (typeof root === 'string') root = document.querySelector(root);
    if (!root) throw new Error('commentsInit: root not found');
    root.innerHTML = `
      <div class="qbc-root">
        <div class="qbc-form">
          <input class="qbc-name" type="text" placeholder="昵称（可选，留空走首次弹窗）" maxlength="30" />
          <textarea class="qbc-text-area" placeholder="说点什么…（Cmd/Ctrl + Enter 发送）" maxlength="500"></textarea>
          <button class="qbc-submit">发布</button>
        </div>
        <div class="qbc-hint">发布需要密码（作者会告诉你）。${PASSWORD_HINT || ''}</div>
        <div class="qbc-list"></div>
      </div>
    `;
    const nameInput = root.querySelector('.qbc-name');
    const textArea = root.querySelector('.qbc-text-area');
    const submitBtn = root.querySelector('.qbc-submit');
    const listEl = root.querySelector('.qbc-list');

    nameInput.value = localStorage.getItem(LS_NICKNAME) || '';
    nameInput.addEventListener('change', () => {
      const v = nameInput.value.trim().slice(0, 30);
      if (v) localStorage.setItem(LS_NICKNAME, v);
    });

    const doSubmit = async () => {
      const text = textArea.value.trim();
      if (!text) return;
      const typed = nameInput.value.trim().slice(0, 30);
      if (typed) localStorage.setItem(LS_NICKNAME, typed);
      submitBtn.disabled = true;
      submitBtn.textContent = '发布中…';
      try {
        _comments.push({
          id: 'c_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
          author: typed || (await ensureNickname()) || '匿名访客',
          text,
          time: Date.now(),
        });
        await saveComments(_comments);
        textArea.value = '';
        renderCommentsList(listEl);
        toast('已发布 ✨');
      } catch (e) {
        if (String(e.message).includes('cancelled')) {
          toast('取消发布');
        } else {
          toast('发布失败：' + e.message.slice(0, 60), 4000);
          // 失败回滚
          _comments.pop();
        }
      } finally {
        submitBtn.disabled = false;
        submitBtn.textContent = '发布';
      }
    };
    submitBtn.onclick = doSubmit;
    textArea.addEventListener('keydown', e => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') {
        e.preventDefault();
        doSubmit();
      }
    });

    const refresh = async () => {
      _comments = await loadComments();
      renderCommentsList(listEl);
    };
    await refresh();
    setInterval(refresh, POLL_INTERVAL);
    document.addEventListener('visibilitychange', () => { if (!document.hidden) refresh(); });
  }

  window.commentsInit = commentsInit;
})();
