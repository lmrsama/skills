---
name: html-deploy-github
description: 把本地 HTML 文件部署到 GitHub Pages 在线链接，自动建仓 + 启用 Pages + 后续修改一键同步。当用户说"HTML 上线"、"部署到 GitHub Pages"、"本地 HTML 转在线链接"、"把这个 html 发布出去让人能访问"时使用。这是 html-deploy-* 系列的基础 skill，仅做"在线化"这一件事，不带评论/AI 等增值能力。
version: 1.0.0
agent_created: true
---

# HTML 离线转在线（GitHub Pages 基础部署）

把本地任意 HTML 文件 → 一个公开可访问的 `https://<user>.github.io/<repo>/` 链接。

仅此一件事。不掺杂评论、AI、密码门——这些请用 `html-deploy-comments` / `html-deploy-ai-edit`（在本 skill 之上叠加）。

---

## 何时用

- 用户给一个本地 HTML（方案、报告、图表、demo 都行）
- 想发个链接给别人打开看
- 后续在 WorkBuddy 里改 HTML，能一键再推上去更新

## 何时不用

- 用户要"评论功能" → 加用 `html-deploy-comments`
- 用户要"AI 帮我改 HTML" → 加用 `html-deploy-ai-edit`
- 用户要私密访问 → GitHub Pages 是公开的，建议改 Cloudflare Pages（暂不支持）

---

## 执行流程

```
Step 1  前置检查 ~/.workbuddy/skills/.shared/github.json
        没有就跑 scripts/setup.py 引导
  ↓
Step 2  确认仓库名（默认从文件名推导）+ 同名仓库存在性提醒
  ↓
Step 3  python3 scripts/deploy.py <html_path> --repo <repo_name>
  ↓
Step 4  返回 URL + 提示后续怎么再次部署
```

---

## Step 1：前置检查

```bash
ls ~/.workbuddy/skills/.shared/github.json
```

- 不存在 → 跑 `python3 ~/.workbuddy/skills/html-deploy-github/scripts/setup.py`，按引导收集 token
- 存在 → 跳到 Step 2

## Step 2：仓库名

默认规则：把 html 文件名小写、空格转 `-`、去后缀。

```
权益卡导流链路汇报v2.html → quan-yi-ka-dao-liu-lian-lu-hui-bao-v2
```

中文文件名建议让用户改成英文短名（如 `qb-report`）。

询问：
> 仓库名要叫什么？默认 `<推导值>`。仓库公开可见，名字会出现在 URL 里。

## Step 3：部署

```bash
python3 ~/.workbuddy/skills/html-deploy-github/scripts/deploy.py \
  <html_path> \
  --repo <repo_name>
```

deploy.py 自动：
1. 读 `~/.workbuddy/skills/.shared/github.json` 拿 token + user
2. 检查目标仓库存在性，不存在就 `POST /user/repos` 创建（public + auto_init）
3. PUT `index.html`（已有就带 sha 覆盖）
4. POST `/pages` 启用 GitHub Pages（main 分支根目录）
5. 输出 `https://<user>.github.io/<repo>/`

## Step 4：返回结果

```
✅ 部署完成
📍 URL：https://your-handle.github.io/qb-report/
ℹ️  GitHub Pages 首次启用需 1-2 分钟才能访问

后续修改：
  python3 ~/.workbuddy/skills/html-deploy-github/scripts/deploy.py <html_path> --repo qb-report
```

---

## 前置引导（首次使用）

`scripts/setup.py` 会带用户走完：

### 1. 创建 GitHub Personal Access Token

打开 https://github.com/settings/tokens/new

- Note：随便写（如 `workbuddy-html-deploy`）
- Expiration：建议 No expiration（或 90 天）
- Scopes：勾选 ✅ `repo`（含子项）；如果未来要加评论/AI，再勾 ✅ `gist`
- 拉到底点 Generate token
- **立即复制** `ghp_xxx`（关闭页面就再也看不到）

### 2. 把 token 给 setup 脚本

```bash
python3 ~/.workbuddy/skills/html-deploy-github/scripts/setup.py
```

脚本会：
- 提示输入 token（不会显示在 prompt 里）
- 调 `GET /user` 反查 username 自动填
- 写到 `~/.workbuddy/skills/.shared/github.json`，权限 600

### 3. 验证

```bash
python3 ~/.workbuddy/skills/html-deploy-github/scripts/setup.py --check
```

输出 `✓ token valid · user: <your-handle>` 即可。

---

## 关键约束

⚠️ **不要让用户在对话里直接发 token**——GitHub 会自动扫描公开消息并撤销 token。引导用户在终端里粘贴。

⚠️ **GitHub Pages 是公开的**——任何拿到 URL 的人都能看到。不适合放真敏感数据。

⚠️ **首次部署后 1-2 分钟才能访问**——GitHub 后台需要构建 Pages，太早打开会 404。

⚠️ **二次部署默认覆盖**——deploy.py 拉取已有 index.html 的 sha 后整体替换，不会保留线上手改。如果担心本地比线上旧，先 `git pull` 或重新生成。

⚠️ **图片/资源**：HTML 里如果引用相对路径图片（`<img src="./xxx.png">`），需要把图片也 push 上去；推荐先用 `embed-images.py`（来自 html-report-publisher 或独立打包工具）把图片转 base64 内嵌成单文件 HTML。

---

## 故障排查

| 症状 | 原因 → 解决 |
|---|---|
| 401 Unauthorized | token 失效或权限不足 → 重新生成、确保勾了 `repo` |
| 404 创建仓库 | username 不对 → 删 github.json 重跑 setup.py |
| Pages URL 打开 404 | 刚部署 < 2 分钟 → 等等；或检查仓库 Settings → Pages 是否真的启用 |
| 图片显示不出 | HTML 里相对路径但图片没 push → 用 embed-images.py 转 base64 |
| 中文仓库名报错 | GitHub 不支持中文仓库名 → 改英文短名 |

---

## 文件结构

```
html-deploy-github/
├── SKILL.md              （本文件）
└── scripts/
    ├── setup.py          （首次引导，生成 ~/.workbuddy/skills/.shared/github.json）
    └── deploy.py         （核心部署：本地 HTML → GitHub Pages）
```

---

## 复用要点（执行前自检）

1. ✅ 不让用户在对话里发 token
2. ✅ 仓库名是英文短横线，不要中文
3. ✅ 默认 public 仓库，提醒用户敏感内容慎放
4. ✅ 首次部署提示用户等 1-2 分钟
5. ✅ 二次部署默认覆盖，不要追问"是否覆盖"——这就是 deploy 的语义
