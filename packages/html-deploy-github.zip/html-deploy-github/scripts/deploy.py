#!/usr/bin/env python3
"""
基础部署：本地 HTML → GitHub Pages 在线链接

用法：
    python3 deploy.py <html_path> --repo <repo_name>
    python3 deploy.py <html_path> --repo <repo_name> --private  # 私有仓库（仍是 GitHub Pages 公开 URL）

零增值：不加密、不评论、不 AI、不读 gist。就是单纯把 HTML 推上去启用 Pages。

需要：~/.workbuddy/skills/.shared/github.json（用 setup.py 生成）
"""
import sys
import os
import json
import base64
import argparse
import urllib.request
import urllib.error
from pathlib import Path

CONFIG_PATH = Path.home() / '.workbuddy' / 'skills' / '.shared' / 'github.json'


def load_config():
    if not CONFIG_PATH.exists():
        print(f'✗ 未配置：{CONFIG_PATH}')
        print('  请先运行：python3 ~/.workbuddy/skills/html-deploy-github/scripts/setup.py')
        sys.exit(1)
    try:
        return json.loads(CONFIG_PATH.read_text(encoding='utf-8'))
    except Exception as e:
        print(f'✗ 配置文件解析失败：{e}')
        sys.exit(1)


def github_api(method, path, token, body=None):
    url = f'https://api.github.com{path}'
    data = json.dumps(body).encode('utf-8') if body else None
    req = urllib.request.Request(url, data=data, method=method, headers={
        'Authorization': f'token {token}',
        'Accept': 'application/vnd.github+json',
        'Content-Type': 'application/json',
    })
    try:
        res = urllib.request.urlopen(req, timeout=30)
        body_bytes = res.read()
        return res.getcode(), json.loads(body_bytes) if body_bytes else None
    except urllib.error.HTTPError as e:
        try:
            err_body = json.loads(e.read())
        except Exception:
            err_body = None
        return e.code, err_body


def deploy(html_path, repo, private=False):
    cfg = load_config()
    token = cfg.get('github_token')
    user = cfg.get('github_user')
    if not token or not user:
        print('✗ config 缺 github_token / github_user，重跑 setup.py')
        sys.exit(1)

    html_path = Path(html_path)
    if not html_path.exists():
        print(f'✗ 文件不存在：{html_path}')
        sys.exit(1)

    print(f'▸ 读取 HTML：{html_path}')
    html = html_path.read_text(encoding='utf-8')
    print(f'  size: {len(html):,} bytes')

    print(f'▸ 检查仓库 {user}/{repo}')
    code, data = github_api('GET', f'/repos/{user}/{repo}', token)
    if code == 404:
        print(f'  仓库不存在，自动创建...')
        code, data = github_api('POST', '/user/repos', token, {
            'name': repo,
            'private': private,
            'auto_init': True,
            'description': 'HTML report deployed via WorkBuddy',
        })
        if code >= 300:
            print(f'✗ 创建仓库失败 {code}: {data}')
            sys.exit(1)
        print(f'  ✓ 已创建（private={private}）')
    elif code == 200:
        print(f'  ✓ 仓库已存在')
    else:
        print(f'✗ 检查仓库异常 {code}: {data}')
        sys.exit(1)

    print(f'▸ 上传 index.html')
    code, file_info = github_api('GET', f'/repos/{user}/{repo}/contents/index.html', token)
    payload = {
        'message': 'Update report',
        'content': base64.b64encode(html.encode('utf-8')).decode('ascii'),
    }
    if code == 200 and file_info and 'sha' in file_info:
        payload['sha'] = file_info['sha']
        print(f'  覆盖现有 index.html (sha {file_info["sha"][:7]})')
    code, data = github_api('PUT', f'/repos/{user}/{repo}/contents/index.html', token, payload)
    if code >= 300:
        print(f'✗ 上传失败 {code}: {data}')
        sys.exit(1)
    print(f'  ✓ 已上传')

    print(f'▸ 启用 GitHub Pages')
    code, data = github_api('POST', f'/repos/{user}/{repo}/pages', token, {
        'source': {'branch': 'main', 'path': '/'}
    })
    if code in (201, 204):
        print(f'  ✓ Pages 已启用')
    elif code == 409:
        print(f'  ✓ Pages 已存在')
    else:
        print(f'  ⚠️ 启用 Pages 返回 {code}（可能已启用，忽略）')

    url = f'https://{user}.github.io/{repo}/'
    print()
    print('============================================')
    print(f'✅ 部署完成')
    print(f'📍 URL：{url}')
    print('============================================')
    print(f'ℹ️  首次启用 Pages 需 1-2 分钟才能访问，过早打开会 404')
    print()
    print(f'后续修改本地 HTML 后再次部署：')
    print(f'  python3 ~/.workbuddy/skills/html-deploy-github/scripts/deploy.py {html_path} --repo {repo}')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('html_path', help='本地 HTML 文件路径')
    ap.add_argument('--repo', required=True, help='目标仓库名（英文短横线）')
    ap.add_argument('--private', action='store_true', help='创建私有仓库（Pages URL 仍公开可访问）')
    args = ap.parse_args()
    deploy(args.html_path, args.repo, args.private)


if __name__ == '__main__':
    main()
