#!/usr/bin/env python3
"""
首次引导：收集 GitHub Personal Access Token，写入 ~/.workbuddy/skills/.shared/github.json

用法：
    python3 setup.py            # 首次引导
    python3 setup.py --check    # 验证现有 token
"""
import sys
import os
import json
import getpass
import argparse
import urllib.request
import urllib.error
from pathlib import Path

CONFIG_DIR = Path.home() / '.workbuddy' / 'skills' / '.shared'
CONFIG_PATH = CONFIG_DIR / 'github.json'


def github_get(path, token):
    req = urllib.request.Request(
        f'https://api.github.com{path}',
        headers={
            'Authorization': f'token {token}',
            'Accept': 'application/vnd.github+json',
        }
    )
    try:
        res = urllib.request.urlopen(req, timeout=15)
        return res.getcode(), json.loads(res.read())
    except urllib.error.HTTPError as e:
        return e.code, None
    except Exception as e:
        print(f'  ⚠️ 网络错误：{e}')
        return -1, None


def check_token(token):
    code, data = github_get('/user', token)
    if code != 200 or not data:
        return None
    return data.get('login')


def load_existing():
    if not CONFIG_PATH.exists():
        return None
    try:
        return json.loads(CONFIG_PATH.read_text(encoding='utf-8'))
    except Exception:
        return None


def write_config(token, user):
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    cfg = {'github_token': token, 'github_user': user}
    CONFIG_PATH.write_text(
        json.dumps(cfg, indent=2, ensure_ascii=False),
        encoding='utf-8'
    )
    os.chmod(CONFIG_PATH, 0o600)


def cmd_check():
    cfg = load_existing()
    if not cfg:
        print('✗ 未配置：~/.workbuddy/skills/.shared/github.json 不存在')
        print('  请先运行：python3 setup.py')
        sys.exit(1)
    token = cfg.get('github_token')
    user = cfg.get('github_user')
    if not token:
        print('✗ 配置文件缺 github_token')
        sys.exit(1)
    actual = check_token(token)
    if not actual:
        print('✗ token 失效或无 /user 权限')
        sys.exit(1)
    if user and actual != user:
        print(f'⚠️ 配置 user={user}，实际 token 属于 {actual}，已自动修正')
        write_config(token, actual)
    print(f'✓ token valid · user: {actual}')


def cmd_setup():
    existing = load_existing()
    if existing and existing.get('github_token'):
        print(f"已存在配置（user: {existing.get('github_user', '?')}）")
        ans = input('覆盖? [y/N]: ').strip().lower()
        if ans != 'y':
            print('已取消')
            return

    print()
    print('============================================')
    print('  GitHub Personal Access Token 引导')
    print('============================================')
    print()
    print('1) 打开浏览器：https://github.com/settings/tokens/new')
    print('2) 填 Note（如 workbuddy-html-deploy）')
    print('3) Expiration：建议 No expiration')
    print('4) Scopes：✅ repo（含全部子项）')
    print('   如果将来想加评论/AI 功能：✅ gist')
    print('5) 拉到底点 Generate token，立即复制 ghp_xxx')
    print()
    token = getpass.getpass('粘贴 token（输入不显示）: ').strip()
    if not token:
        print('✗ 未输入 token')
        sys.exit(1)
    if not token.startswith(('ghp_', 'github_pat_')):
        print('⚠️ 看起来不像 PAT（应以 ghp_ 或 github_pat_ 开头），仍尝试验证...')

    print()
    print('▸ 验证 token...')
    user = check_token(token)
    if not user:
        print('✗ token 验证失败：401 或网络问题')
        sys.exit(1)
    print(f'  ✓ token 有效，username: {user}')

    write_config(token, user)
    print()
    print(f'✓ 已写入：{CONFIG_PATH}')
    print(f'  权限：600（仅当前用户可读写）')
    print()
    print('下一步：')
    print('  python3 ~/.workbuddy/skills/html-deploy-github/scripts/deploy.py <html> --repo <name>')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--check', action='store_true', help='验证现有 token')
    args = ap.parse_args()
    if args.check:
        cmd_check()
    else:
        cmd_setup()


if __name__ == '__main__':
    main()
