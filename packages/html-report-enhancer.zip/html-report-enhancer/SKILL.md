---
name: html-report-enhancer
description: 把方案 HTML（或由 Word/PPT/MD 转成的 HTML）一键改造成在线汇报链接——老板能评论、AI 实时改、版本可撤回、PC/手机双视图。适用"HTML 做成汇报版"、"部署到在线"、"让老板能评论改方案"、"方案转 HTML 在线汇报"等需求。产物：GitHub Pages 链接 + 密码。
version: 2.12.0
agent_created: true
---

# HTML 汇报助手

把 Word / PPT / Markdown 方案 → HTML → 云端链接。自带评论、AI 实时改、版本撤回、双视图。

## v2.12.0 重大升级：SCF 中转架构（必读）

### 背景
v2.11.x 把 GitHub PAT 明文/密文嵌在 HTML 里，GitHub secret-scanning 会**自动 revoke** 这种 token，老板刚评论就写失败。Cloudflare Worker `*.workers.dev` 在国内被 DNS 污染，也不行。

### 新架构
```
访客浏览器 ──(password+nickname)──> 腾讯云 SCF ──(PAT)──> GitHub Gist
           前端不含任何 GitHub 凭证        token 只在 SCF 环境变量里
```

- **token 永不暴露**、永不被 revoke
- **国内访问稳**（腾讯自家域 `*.tencentscf.com`）
- **旋转 token 零前端改动**（只改 SCF env）
- 前端读走 `GET {WORKER_BASE}/gist`，写走 `POST {WORKER_BASE}/gist/file`

### 依赖
`html-deploy-comments` v2.0（同系列 skill）提供 SCF 代码 + 部署指南。首次需按它的 SKILL.md 配置 SCF，拿到 URL 填进本 skill 的 `config.json` → `worker_base`。

### 配置
```json
{
  "github_token": "ghp_xxx",
  "github_user": "用户名",
  "gist_id": "xxx",
  "ai_provider": "deepseek",
  "ai_api_key": "sk-xxx",
  "ai_endpoint": "https://api.deepseek.com/v1/chat/completions",
  "ai_model": "deepseek-chat",
  "deploy_repo": "xxx",
  "deploy_password": "xxx",
  "worker_base": "https://xxx.ap-guangzhou.tencentscf.com"
}
```

`deploy.py` 会把 HTML 里的 `__WORKER_BASE__` 占位符替换为 `worker_base` 的值。

---

# HTML 汇报助手

把 Word / PPT / Markdown 方案 → HTML → 云端链接。自带评论、AI 实时改、版本撤回、双视图。

## 核心能力（对用户宣传口径）

- **颗粒度评论**：点任意文字/图片/数据直接评；PC 支持 ⌘+click 多选 / 拖动框选（手机无框选，其他能力一致）
- **AI 实时改**：选元素描述改动（换词/改色/删元素），3-15 秒生效；单次最多 6 个元素（超出时前端立即 toast）
- **版本撤回**：每次 AI 改前存 snapshot，点「↩️ 撤回此操作」恢复到改之前
- **评论导出**：方案 owner 一键导出全部反馈 → 丢给 WorkBuddy 批量返工
- **PC/手机双视图**：同链接自适应，能力一致
- **零安装**：浏览器输密码即用；密钥 AES-GCM 加密后嵌进 HTML
- **新手引导**：3 Tab（🏠 关于 / 💻 PC 端 / 📱 手机端）；手机/窄屏自动上下布局；首次访问自动弹一次

## 交互模型（最终版）

**PC**
- 只读态：纯阅读，业务 onclick 正常
- 批注态：点有评论元素 → 打开侧栏过滤；点空白关面板
- **⌘/Ctrl + click 元素**：选中 + 弹深色小气泡（💬评论 / ✨AI修改）
- **⌘ 拖拽空白**：框选多元素
- **气泡按钮 → inline 输入框**（320px，Enter 屏蔽，必须点【发送】）
- **发送/取消后**：自动回默认态（关输入框+关工具栏+清选区）
- 空内容点发送：无响应（保持状态）
- 选中第 7 个：立即 toast「Demo 上限 6 个，超出不处理」

**手机**
- 只读态：点元素不阻断业务 onclick；首次点 commentable 元素 toast 提示切批注（每设备只一次）
- 批注态：点元素弹**底部抽屉卡片**（标题 + 评论 list + 输入框 + 「💬 发表评论 / ✨ AI 修改」双按钮）

**版本撤回语义**：只存操作前 snapshot。撤回=恢复该 snapshot + 截断云端 versions 到 ≤该条 + 后续 AI 评论标 ai_reverted。最多 5 条。

## 关键防呆（必读）

### 1. 持久化前 strip 运行时 class
saveVersion / restoreLatestSnapshot / deploy 脚本 merge 都必须 strip：
`selected-target / has-comments / has-edit-notes / open / active / panel-open / panel-expanded / show-comments / selection-mode / mobile-card-open`
动态注入元素也要移除：`.comment-badge / .edit-note-badge / .module-comment-btn / .target-flag`
否则当前用户瞬时态会冻结进 snapshot 污染所有用户。

### 2. snapshot 图片占位符
snapshot 里 base64 图 src → `__IMG_PLACEHOLDER_${idx}__`（带 data-img-idx），restore 前 `collectImageSrcs()` 从当前 DOM 拿真 src，replace 后 `restoreImagePlaceholders()` 还原。单 snapshot 从 280KB 降到 ~80KB。

### 3. deploy 跳过含占位符的 snapshot
deploy 脚本 merge 前 `if '__IMG_PLACEHOLDER' in snapshot: skip merge`，否则线上图片全丢。UI 重构时用 `--force-local`。

### 4. Gist API 1MB 限制
`GET /gists/:id` 返回的 file.content > 1MB 会 truncated=true。loadVersions 必须检测 truncated 并 fallback 到 `file.raw_url`；解析失败**必须抛错**而非静默返回 []（否则 saveVersion 会用 [] 覆盖整个历史）。

### 5. AI 选择器防呆（三层）
- 传给 AI 的 HTML 先 stripRuntimeForAI
- systemPrompt 禁用运行时 class，必须用语义 class 或 `data-section`/`data-target-id`
- applyAIResult 兜底：找不到时剥离运行时 class 再查一次；`sectionEl.matches(sel)` 匹配自身
- applyAIResultMulti 有任何失败必须抛错（之前吞错导致 "AI 已执行但页面没变"）

### 6. capture 阶段 stopPropagation 会终止事件
不要在容器上加 `addEventListener('click', e=>e.stopPropagation(), true)`——会阻止内部 button 的 inline onclick。用 document 级白名单 `closest('#bubbleInput') return;` 或容器 capture 监听自己处理（data-action 模式）。

### 7. 手机只读态不阻止 click
`e.preventDefault + stopPropagation` 会拦 stage-tab / task-btn 的业务 onclick。只读态只**异步**（setTimeout 0）触发 toast 提示切批注。

### 8. textarea/input Enter 全屏蔽
全局 keydown capture 拦截，防误触发送。

### 9. 移动端 --vh 真实视口
Chrome / Safari 底 bar 收起导致 `100vh` 跳变。JS 动态 `--vh = visualViewport.height / 100`，所有 vh 改 `calc(var(--vh,1vh) * X)`。

### 10. no-cache meta
`<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">` + Pragma/Expires，防浏览器缓存旧代码，否则用户看不到新部署的修复。

## 数据结构

评论扁平化：`{all: [{text, author, time, type, scope, section?, targetId?, targets?, version?, aiResponse?}]}`。type: `normal | ai_executed | ai_pending | ai_failed | ai_reverted`。scope: `global | section | target | multi`。

## 前置条件

config.json：
```json
{
  "github_token": "ghp_xxx",           // 权限 gist + repo
  "github_user": "用户名",
  "gist_id": "xxx",                    // 新建 public gist，filename=comments.json, content={}
  "ai_provider": "deepseek",            // 必须 Deepseek（混元 CORS 失败）
  "ai_api_key": "sk-xxx",
  "ai_endpoint": "https://api.deepseek.com/v1/chat/completions",
  "ai_model": "deepseek-chat",
  "deploy_repo": "xxx",
  "deploy_password": "xxx",
  "worker_base": "https://xxx.ap-guangzhou.tencentscf.com"  // v2.12 新增：SCF 中转 URL
}
```

## 标准工作流

1. 用户给 HTML（或 Word/PPT/MD 让 AI 先转 HTML）
2. 目标容器加 `class="commentable" data-section="xxx"`
3. 复制参考实现的 CSS/DOM/JS：`/Users/lmrsama/WorkBuddy/20260415174903/权益卡导流链路汇报v2.html`
4. 调整 `TARGET_SELECTORS = {text:[], image:[], data:[]}` 匹配目标 HTML
5. 替换 `GIST_ID` / `sectionNames`，保留 `__ENCRYPTED_KEYS__`
6. `embed-images.py` 内嵌图片
7. `deploy.py --password X --repo X`（UI 重构或数据修复后加 `--force-local`）
8. 返回 URL + 密码

## 故障排查

| 症状 | 原因 → 解决 |
|---|---|
| AI "已执行" 但页面没变 | applyAIResultMulti 吞错 / CDN 缓存旧代码 → 已修 throw；用户 Cmd+Shift+R |
| 某些元素默认显示蓝色选中态 | snapshot 污染 selected-target → saveVersion/restore/deploy 三处 strip；脚本洗老 Gist |
| 线上图片全丢（`__IMG_PLACEHOLDER`） | deploy 合并了瘦身 snapshot → `--force-local` + deploy 跳过 placeholder |
| 版本历史重复"备份"条目 | 旧双条记录 → v2.11.19 只存一条操作 |
| PC 取消/关闭按钮点不动 | 容器 capture stopPropagation → 改 document 级白名单 |
| 手机只读态卡死业务交互 | preventDefault 拦了 onclick → 只读态异步 toast |
| textarea Enter 误发送 | 未全局拦截 → 全局 keydown capture 屏蔽 textarea/input 的 Enter |
| 移动端底 bar 跳变 | vh 是固定最大视口 → `--vh` + visualViewport 监听 |
| `Failed to fetch` 调 AI | 用了混元等不支持跨域 → 必须 Deepseek |
| 子元素 click 触发模块评论 | 未 stopPropagation → bindTargetClicks 第一行加 |
| 回滚后刷新变回去 | 旧版本 → v2.11.19 撤回=截断云端 versions 到 ≤目标 |
| 401 | token 失效 → 重新生成 |

## 数据修复脚本速查

**清空 versions.json**：
```python
import json, urllib.request
with open(__import__('os').path.expanduser('~/.workbuddy/skills/html-report-enhancer/config.json')) as f: cfg = json.load(f)
urllib.request.urlopen(urllib.request.Request(
    f"https://api.github.com/gists/{cfg['gist_id']}",
    data=json.dumps({'files': {'versions.json': {'content': '[]'}}}).encode(),
    headers={'Authorization': f'token {cfg["github_token"]}', 'Content-Type': 'application/json'},
    method='PATCH'))
```

**清洗 snapshot 运行时 class**（不清空，保留版本）：正则 `class="([^"]*)"` → 过滤掉 runtime classes。完整实现见 memory 14:13 v2.11.15。

**批量把 ai_executed 标 ai_failed**（旧版生成的假成功）：遍历 comments.all，`type==='ai_executed' → 'ai_failed' + aiResponse='旧版未生效，请重试'`。

## 文件结构

```
html-report-enhancer/
├── SKILL.md
├── config.json
└── scripts/
    ├── enhance.py
    ├── deploy.py         # 含 merge + --force-local + __IMG_PLACEHOLDER 检测
    └── embed-images.py
```

参考实现（始终最新）：`/Users/lmrsama/WorkBuddy/20260415174903/权益卡导流链路汇报v2.html`

## 复用要点

1. 不要让用户在对话里发 key（GitHub 会自动扫描撤销）
2. UI 重构后必须 `--force-local`
3. 任何 `.container` DOM 替换后必须 `assignTargetIds() + bindTargetClicks() + injectModuleCommentBtns()`
4. 子元素 click 必须 `stopPropagation()`（第一行）
5. AI 调用前必须 `stripRuntimeForAI(cloned)`
6. 新 HTML 布置需调 `TARGET_SELECTORS` 匹配结构
