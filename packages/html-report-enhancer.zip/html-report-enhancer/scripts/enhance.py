#!/usr/bin/env python3
"""
HTML汇报稿一键增强脚本 v2.0
功能：
1. 扫描HTML图片 → 压缩+base64内嵌
2. 注入云端评论系统（GitHub Gist）
3. 注入PC/手机视图切换
4. 注入AI修改能力（Deepseek）
5. 注入版本管理+回滚

用法：
  python3 enhance.py <html_path> --sections "key1:中文名1,key2:中文名2"
"""
import sys, os, re, json, base64, argparse, io
from pathlib import Path

try:
    from PIL import Image
except ImportError:
    print("需要安装Pillow: pip3 install Pillow")
    sys.exit(1)

SCRIPT_DIR = Path(__file__).parent
CONFIG_PATH = SCRIPT_DIR.parent / 'config.json'
TEMPLATE_DIR = SCRIPT_DIR / 'templates'


def load_config():
    if not CONFIG_PATH.exists():
        print(f"❌ 配置不存在：{CONFIG_PATH}")
        print("按 SKILL.md 引导填写 config.json")
        sys.exit(1)
    with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
        cfg = json.load(f)
    required = ['github_token', 'gist_id', 'ai_api_key']
    missing = [k for k in required if not cfg.get(k)]
    if missing:
        print(f"❌ config.json 缺字段: {missing}")
        sys.exit(1)
    return cfg


def embed_images(html, html_dir):
    pattern = re.compile(r'''src=(["'])((?!https?://|data:)[^"']+\.(?:png|jpg|jpeg|gif|webp))\1''', re.IGNORECASE)
    replacements = []
    for match in pattern.finditer(html):
        quote, rel = match.group(1), match.group(2)
        abs_path = (html_dir / rel).resolve()
        if not abs_path.exists():
            print(f"  [skip] {rel}")
            continue
        img = Image.open(abs_path)
        if img.width > 600:
            ratio = 600 / img.width
            img = img.resize((600, int(img.height * ratio)), Image.LANCZOS)
        if img.mode != 'RGB':
            img = img.convert('RGB')
        buf = io.BytesIO()
        img.save(buf, 'JPEG', quality=85, optimize=True)
        b64 = base64.b64encode(buf.getvalue()).decode('utf-8')
        print(f"  [img] {rel}: {len(b64)//1024}KB")
        replacements.append((match.group(0), f'src={quote}data:image/jpeg;base64,{b64}{quote}'))
    for old, new in replacements:
        html = html.replace(old, new, 1)
    return html


def inject_all(html, section_map, config):
    """注入所有增强能力：CSS + DOM + JS"""
    # 读取综合模板
    combined_template = (TEMPLATE_DIR / 'all-in-one.html').read_text(encoding='utf-8')

    css_match = re.search(r'<!-- CSS START -->(.*?)<!-- CSS END -->', combined_template, re.DOTALL)
    dom_match = re.search(r'<!-- DOM START -->(.*?)<!-- DOM END -->', combined_template, re.DOTALL)
    js_match = re.search(r'<!-- JS START -->(.*?)<!-- JS END -->', combined_template, re.DOTALL)

    css = css_match.group(1).strip() if css_match else ''
    dom = dom_match.group(1).strip() if dom_match else ''
    js = js_match.group(1).strip() if js_match else ''

    # 替换JS中的配置
    js = js.replace('__GIST_ID__', config['gist_id'])
    js = js.replace('__AI_ENDPOINT__', config.get('ai_endpoint', 'https://api.deepseek.com/v1/chat/completions'))
    js = js.replace('__AI_MODEL__', config.get('ai_model', 'deepseek-chat'))
    js = js.replace('__SECTION_NAMES_JSON__', json.dumps(section_map, ensure_ascii=False))

    # 注入到HTML
    if '</style>' in html:
        html = html.replace('</style>', f'\n{css}\n</style>', 1)
    else:
        html = html.replace('</head>', f'<style>{css}</style>\n</head>', 1)

    html = html.replace('<body>', f'<body>\n{dom}', 1)
    html = html.replace('</body>', f'<script>{js}</script>\n</body>', 1)

    return html


def mark_commentable(html, section_keys):
    """提示用户手动标注，或扫描常见容器"""
    # 这步建议手动做，脚本只提示
    missing = []
    for key in section_keys:
        if f'data-section="{key}"' not in html:
            missing.append(key)
    if missing:
        print(f"\n⚠️ 以下section未在HTML中标注 class='commentable' data-section='xxx':")
        for k in missing:
            print(f"   - {k}")
        print("请手动在需要评论的容器上加这两个属性，然后重新运行脚本")


def enhance(html_path, section_map):
    html_path = Path(html_path).resolve()
    config = load_config()

    with open(html_path, 'r', encoding='utf-8') as f:
        html = f.read()

    print(f"▸ 处理 {html_path.name}")

    # 检查标注
    mark_commentable(html, list(section_map.keys()))

    print("▸ 图片内嵌")
    html = embed_images(html, html_path.parent)

    print("▸ 注入评论+AI+视图切换+版本管理")
    html = inject_all(html, section_map, config)

    with open(html_path, 'w', encoding='utf-8') as f:
        f.write(html)

    size = html_path.stat().st_size // 1024
    print(f"\n✅ 完成：{html_path}")
    print(f"   大小：{size}KB")
    print(f"\n下一步：运行 deploy.py 部署上线")


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('html_path')
    ap.add_argument('--sections', required=True, help='格式: key1:中文名1,key2:中文名2')
    args = ap.parse_args()

    section_map = {}
    for pair in args.sections.split(','):
        if ':' in pair:
            k, v = pair.split(':', 1)
            section_map[k.strip()] = v.strip()

    enhance(args.html_path, section_map)
