# GitHub Gist 评论云存储配置

## 为什么用Gist

- 免费、稳定、零运维
- 评论以JSON形式存私密Gist里
- HTML前端直接调GitHub API读写

## 配置步骤（一次性）

### Step 1: 生成GitHub Personal Access Token

1. 登录 GitHub → 右上角头像 → **Settings**
2. 左侧最下面 **Developer settings** → **Personal access tokens** → **Tokens (classic)**
3. **Generate new token (classic)**
4. Note 填：`html-comments`
5. Expiration 选：90 days（到期再换）
6. Scopes：**只勾 `gist`** 这一个权限
7. 生成后立刻复制（形如 `ghp_xxxxxxxx`），页面关闭后看不到

### Step 2: 创建评论存储Gist

1. 访问 https://gist.github.com/
2. Filename 填：`comments.json`
3. 内容填：`{}`
4. 点右下角 **Create secret gist**（私密的）
5. 复制URL最后一段作为 Gist ID（形如 `3c42d1323e54dfabcddb26635bb68944`）

### Step 3: 写入配置文件

把 Token 和 Gist ID 写到：

```
~/.workbuddy/skills/html-report-enhancer/config.json
```

内容：
```json
{
  "github_token": "ghp_xxxxxxxx",
  "gist_id": "3c42d1323e54dfabcddb26635bb68944"
}
```

## 安全说明

- Token 相当于密码，不要外发
- 发给老板的HTML里会带Token——能改你的Gist评论，但不能操作你的其他GitHub资源
- 汇报完可以去撤销Token，下次用新的
- 如果同时给多人发，建议每个人用独立的Gist（不共享评论）

## 每次复用

配置好以后，以后任何 HTML 汇报直接调用本 Skill 就行，Token 和 GistID 自动从 config.json 读取。
