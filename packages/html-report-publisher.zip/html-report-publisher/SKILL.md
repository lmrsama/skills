---
name: html-report-publisher
description: 把 Word / PPT / Markdown / 纯文字方案转成带评论、AI 实时改、版本撤回能力的在线 HTML 汇报链接，一键部署到 GitHub Pages。老板/同事打开链接就能在方案上直接评论、让 AI 当场改。当用户说"方案做成在线汇报版"、"HTML 汇报"、"让老板能评论改方案"、"Word/PPT 转 HTML 在线评审"、"部署汇报到在线"时使用。
version: 1.2.0
agent_created: true
---

# HTML 汇报助手

把静态方案（Word / PPT / Markdown / 纯文字）转成在线链接——老板打开能看、能评、可选让 AI 当场改方案，版本可撤回。

## 两种部署模式

| 模式 | 能力 | 何时选 |
|---|---|---|
| **基础版**（`enable_ai=false`） | 评论 + 多端视图 + 评论导出 Markdown | 只需要让人看和评论；零 AI 成本；最稳 |
| **完整版**（`enable_ai=true`） | 基础版 + AI 实时改 HTML + 版本撤回 + 密码门 | 需要快速迭代方案；要 DeepSeek API key |

⚠️ **AI Provider 必须用 DeepSeek**——腾讯混元等不支持浏览器跨域，会 `Failed to fetch`。

---

## 执行总流程（必按此顺序）

```
Step 1  前置检查 (config.json)
  ↓
Step 2  ❓ 必问：基础版 还是 完整版？(写入 enable_ai)
  ↓
Step 3  ❓ 必问：预设格式 还是 保留原稿？
  ↓
Step 4  生成 HTML：
        基础版 → python3 scripts/build_basic.py <out>
        完整版 → cp templates/reference.html <out>
        然后注入正文 + 修改 sectionNames + TARGET_SELECTORS
  ↓
Step 5  健康检查：python3 scripts/verify.py <out>
        所有 P0 必须为 0 才能部署
  ↓
Step 6  部署：python3 scripts/deploy.py <out> --force-local
```

**关键铁律：每一步必须按上面顺序执行，跳过任何一步都会出 bug**。

---

## Step 1：前置检查

读 `~/.workbuddy/skills/html-report-publisher/config.json`：

- 不存在 → 进入 [前置引导]
- 存在但缺 `enable_ai` 字段（旧版本）→ 询问用户后补字段
- 完整 → 跳到 Step 2

## Step 2：询问 AI 模式（**必问**）

```
> 这个汇报版要不要带 AI 实时改写功能？
>
> A. 基础版（推荐）——评论 + 导出，零 AI 成本，稳定
> B. 完整版——评论 + AI 改稿 + 版本撤回，需要 DeepSeek API Key
```

把结果写入 `config.json`：`"enable_ai": true | false`。

**绝对不要擅自决定**——基础版和完整版生成路径完全不同，没有"中间态"。

## Step 3：询问内容格式（**必问**）

```
> 内容怎么处理？
>
> A. 用 skill 预设格式重新排版（推荐，QB 蓝白风、卡片化）
> B. 保留原稿层级（用 convert.py 转 Word/PPT/MD → HTML）
```

## Step 4：生成 HTML

### 基础版（enable_ai=false）

```bash
python3 ~/.workbuddy/skills/html-report-publisher/scripts/build_basic.py \
  <output_path> \
  --title "你的标题" \
  --subtitle "你的副标题"
```

build_basic.py 会从 `templates/reference.html` 自动：
- 删除 AI 相关 DOM（bubble AI 按钮、panel AI tab、versionModal、aiSubToolbar、mcc AI 按钮）
- 重写 HELP_STEPS 三步（去 AI 字样）
- 重写 6 个 HELP_ANIMS SVG（带 `class="help-svg"` 护栏）
- 重写「关于」页（保留四章节结构，核心能力删 3 项 AI 项）
- 短路 unlockKeys / openVersions
- 给 body 加 `noai` 类
- 把 .container 区清空成 placeholder（等你注入正文）

**生成后必做**：
1. 编辑输出文件，把 `.container` 里的 placeholder 替换为实际汇报正文
2. 包装成 `<div class="commentable" data-section="xxx">...</div>` 让评论可用
3. 修改 JS 里的 `sectionNames` 中文映射（约 800 行附近）
4. 修改 JS 里的 `TARGET_SELECTORS`（text/image/data 三组选择器，匹配你的 DOM）
5. 改 `<title>`、`viewport meta`（无需改其他 HTML 标签）

### 完整版（enable_ai=true）

直接 cp `templates/reference.html` 作为骨架，**不要做减法**——只改内容、sectionNames、TARGET_SELECTORS。

```bash
cp ~/.workbuddy/skills/html-report-publisher/templates/reference.html <output_path>
# 然后注入正文 + 改 sectionNames + 改 TARGET_SELECTORS
```

## Step 5：健康检查（**部署前必跑**）

```bash
python3 ~/.workbuddy/skills/html-report-publisher/scripts/verify.py <output_path>
```

**P0 必须 0 个**才能部署。verify.py 检查项：

| 项 | 描述 | 级别 |
|---|---|---|
| 底部裸露 JS | `</script>` 后到 `</body>` 之间不应有非空内容 | P0 |
| AI DOM 残留 | bubble AI 按钮、panel AI tab、mcc AI、versionModal、aiSubToolbar 必须全 0 | P0 |
| HELP_STEPS / HELP_ANIMS 含 'AI' | 基础版不能有 | P0 |
| HELP_ANIMS SVG 缺 `class="help-svg"` | 6 个都必须有 | P0 |
| unlockKeys 被短路为 return null | 评论也需要 token 鉴权！基础版不能短路 | P0 |
| `__ENCRYPTED_KEYS__` 残留 | 基础版应为 `''` | P0 |
| .container 不唯一 | 多个或缺失 | P0 |
| sectionNames 缺映射 | data-section 的中文名 | P1 |
| TARGET_SELECTORS 是默认值 | 提醒按你的 DOM 替换 | P1 |
| `__GIST_ID__` 占位 | 提示 deploy.py 会替换 | P1 |
| `<title>` / 署名是 placeholder | 提醒替换 | P1 |
| 缺 viewport / no-cache meta | 手机/缓存问题 | P1 |

## Step 6：部署

```bash
python3 ~/.workbuddy/skills/html-report-publisher/scripts/deploy.py <output_path> --force-local
```

deploy.py 自动：
1. 读 config.json `enable_ai`：**两种模式都会加密 token**（评论读写 Gist 需要 token 鉴权），区别是完整版额外加密 ai_key，基础版 ai_key 为空
2. 替换 `__GIST_ID__` 占位符
3. 创建/更新 GitHub 仓库（仓库名取自 config.json `deploy_repo`）
4. 推送 index.html
5. 启用 GitHub Pages

返回 `https://<user>.github.io/<repo>/` + 访问密码。**两种模式都需要密码**（用户首次评论时输入一次，之后 localStorage 缓存自动记住）。

`--force-local` = 不从 Gist 拉历史 snapshot 合并（**首次部署、UI 重构、修 bug 后必须加这个 flag**）。

---

## 前置引导（首次使用）

按顺序收集 4 类参数：

### 1. GitHub Personal Access Token（必需）
- https://github.com/settings/tokens/new
- Expiration: No expiration / 90 天
- Scopes: ✅ `repo`（含子项）✅ `gist`
- 复制 `ghp_xxx`

### 2. GitHub Gist ID（必需）
- https://gist.github.com 创建 **public** gist（不是 secret！）
- Filename: `comments.json`
- Content: `{}`
- gist_id = URL 末尾那串字符

### 3. DeepSeek API Key（仅完整版需要）
- https://platform.deepseek.com/ → 注册 → 充 5 元 → 创建 API Key
- 复制 `sk-xxx`

### 4. 部署仓库名 + 访问密码（必需）
- 仓库名：会自动创建（如 `my-report-2026`）
- 访问密码：完整版用于 AI key 解密；基础版纯占位

### 写入 config.json

```json
{
  "github_token": "ghp_xxx",
  "github_user": "<token 反查得到，自动填>",
  "gist_id": "xxx",
  "enable_ai": false,
  "ai_provider": "deepseek",
  "ai_api_key": "sk-xxx",
  "ai_endpoint": "https://api.deepseek.com/v1/chat/completions",
  "ai_model": "deepseek-chat",
  "deploy_repo": "my-report",
  "deploy_password": "demo2026"
}
```

⚠️ 用户**绝不能**在公开聊天里发 token / api key，GitHub 会自动扫描撤销。

---

## 文件结构

```
html-report-publisher/
├── SKILL.md                    （本文件）
├── config.example.json         （配置示例）
├── config.json                 （首次引导后生成 · 不入库）
├── templates/
│   ├── reference.html          （完整版骨架，AI + 评论 + 版本撤回全功能）
│   └── style-template.css      （预设格式 CSS）
└── scripts/
    ├── build_basic.py          （★ 基础版一键生成，从 reference.html → 无 AI 版）
    ├── verify.py               （★ 部署前健康检查，P0/P1 分级）
    ├── deploy.py               （部署到 GitHub Pages，自动识别 enable_ai）
    ├── embed-images.py         （base64 内嵌图片）
    └── convert.py              （Word/PPT/MD → HTML，保留原始格式时用）
```

★ = v1.2 新增

---

## 关键铁律（按违反频率倒序）

### 铁律 1：基础版用 `build_basic.py`，不要手动改

历史 bug 大部分来自手动改 reference.html 漏掉某处。**永远用脚本**——脚本里写好了"减法"的所有点位。如果脚本有 bug，改脚本，不要绕过它。

### 铁律 2：所有新 JS 必须包在 `<script>...</script>` 内

```
</script>
        (function(){ ... })();   ← ❌ 裸露代码会作为 DOM 文本渲染！
</body>
```

正确：

```
</script>

    <script>
        (function(){ ... })();
    </script>
</body>
```

**症状**：页面底部出现 JS 源码文本（"(function(){..."）。

### 铁律 3：基础版**只做减法**，不要篡改 reference.html 布局

reference.html 的 `#helpModal`、`#helpAnim`、`#helpSteps`、`.view-switcher` 等组件**布局逻辑由原 JS 在运行时判断**。

**绝对禁止**在 CSS 里强制覆盖这些属性：`flex-direction`、`width`、`min-height`、`max-height`、`transform`、`left`、`top`、`display`。

**典型坑**：
- ❌ `.view-switcher { left: 50% !important }` → 把左上角按钮拉到中间，挡住居中标题
- ❌ `#helpAnim { max-height: 240px !important }` → 手机端图示截断
- ❌ 在 @media 里覆盖 `#helpModal` 子容器 flex-direction → 破坏原 JS 布局判断

**唯一例外**：原模板用 inline style 写了 `min-height: 340px` 等绝对值，CSS 必须 `!important` 才能覆盖时——可以但要保守（只收紧、不改方向）。

### 铁律 4：HELP_ANIMS 重写时 SVG 必须加 `class="help-svg"`

reference.html 原 CSS 写好了 `.help-svg { width: 100%; height: 320px; max-width: 360px; }`。如果 SVG 没这 class，浏览器会按 viewBox 比例自动拉伸——280×200 在 500px 容器里会撑成 357px 高，把弹窗撑爆。

```html
❌ <svg viewBox="0 0 280 200" style="max-width:100%;height:auto;">
✅ <svg class="help-svg" viewBox="0 0 280 200">
```

build_basic.py 已经处理这个，不需要手动写。

### 铁律 5：「关于」页 = 介绍 HTML 汇报助手这个**工具**，不是介绍方案内容

「关于」页给第一次打开链接的读者看，要让他们知道"我现在在用什么工具"。

❌ 错：把"关于"改成"用户反馈 Field Notes / 这是对 94 张便签的整理..."（这是方案内容，不是工具介绍）

✅ 对：保留 reference.html 原四章节结构（🧩 是什么 / ❗ 解决什么问题 / ⚡ 核心能力 / 🚀 怎么用），基础版只在"核心能力"列表里删 `AI 实时改` / `版本可撤回` / `输密码` 三项。

build_basic.py 已经处理这个。

### 铁律 6：PC 宽屏要用自适应列数，不要硬写 1-2 列

PC 大屏（1600px+）锁 max-width: 1100px 会浪费两侧留白，内容被迫挤成双列。

```css
.themes-grid { grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); max-width: 1360px; }
.notes-wall { columns: 4 280px; max-width: 1360px; }
```

`auto-fit + minmax` 让浏览器按屏宽自动算列数（屏宽够时 3、4、5 列）。

### 铁律 7：基础版不要搞折叠/展开

总条数 < 50 时全量展示。折叠交互对 < 50 条的列表是过度设计：
- 小 tab（4 条）也显示"展开全部"按钮，用户困惑
- 展开后没收起又是反模式
- 移动端用户滚滚就行，多一次点击反而是负担

### 铁律 8：手机 CSS 的合法职责

手机端 `@media (max-width: 640px)` 里**只能动**：

- 字号（font-size）
- 行高（line-height）
- padding / margin
- 网格列数（grid-template-columns: 1fr）
- 卡片圆角（border-radius）

**禁止动**：position、top、left、transform、width、height、display、flex-direction（除非已在原模板的 `body.mobile-view` 命名空间里有定义）。

**手机可读性数值规范**（必须遵守）：

| 元素 | 数值 |
|---|---|
| 正文字号 | ≥ 13px（最小 12px，仅辅助说明） |
| 正文行高 | 1.7 ~ 1.8 |
| 标题字号 | h1 24-28px / h2 20-22px / h3 17-18px |
| 卡片 padding | 16-20px（不要 < 12px） |
| 网格列数 | 强制单列 `1fr` |
| 卡片间距 | 12-16px |
| 流程/步骤图 | 纵向堆叠（不要横向缩放成迷你版） |

**反例**（粗暴缩窄）：把 PC 卡片直接 width:100% 渲染——文字挤、行间距塌、按钮一行 4 个全压扁。
**正例**：单列 + 字号 13-14px + 行高 1.75 + padding 16px + 流程图 vertical layout。

---

## 故障排查表

| 症状 | 原因 → 解决 |
|---|---|
| 页面底部出现 JS 源码文本 | 新 JS 没包 `<script>` 标签 → 用脚本生成、不要手改 |
| 评论发不出 / 加载评论 404 | `__GIST_ID__` 没替换 → 检查 deploy.py 输出，重跑 deploy |
| AI "已执行" 但页面没变 | applyAIResultMulti 吞错 / CDN 缓存 → 已修 throw；硬刷新 |
| 点 AI 修改没密码弹窗 | toast 在 unlock 之前 → 必须先 unlockKeys 再 showTopToast |
| 密码弹窗被 toast 遮挡 | 用了原生 prompt → 用自定义 modal `showPasswordDialog` |
| 刷新后 AI 修改回到改之前 | latest 和 versions 混用 → v1.1 已分离 |
| 线上图片全丢 | deploy 合并了 placeholder snapshot → 加 `--force-local` |
| 手机布局密密麻麻 | 只做响应式宽度 → 按"手机 CSS 合法职责"重排字号/行高 |
| `Failed to fetch` 调 AI | 用了腾讯混元等 → 必须 DeepSeek |
| 401 GitHub API | token 失效 → 重新生成 |
| 引导弹窗 SVG 撑爆 | SVG 缺 `class="help-svg"` → 加上 |
| view-switcher 挡标题 | 写了全局 `left: 50%` → 删掉，回到 reference.html 原 PC 左上角 |
| PC 宽屏内容挤成双列 | max-width 锁 1100 → 拉到 1360 + auto-fit minmax |

---

## 关键防呆（持久化层）

1. **持久化前 strip 运行时 class**：saveVersion / restoreLatestSnapshot / deploy merge 必须 strip `selected-target / has-comments / open / active / panel-open / show-comments / selection-mode / mobile-card-open`
2. **snapshot 图片占位符**：base64 → `__IMG_PLACEHOLDER_${idx}__`，恢复时从 DOM 拿 src 回填
3. **deploy 跳过含占位符的 snapshot**（否则图片全丢），用 `--force-local` 跳过合并
4. **Gist content > 1MB 会 truncated**：loadVersions 检测 truncated 并 fallback raw_url；解析失败 throw 而非返回 `[]`
5. **versions vs latest 分离**：versions.json 存改前 snapshot（撤回用），latest.json 存改后 DOM（刷新恢复用）
6. **AI 密码弹窗**：必须 Promise-based 自定义 dialog，z-index > toast；密码连错 3 次自动放弃
7. **AI 调用前** 必须 `stripRuntimeForAI(cloned)` 清运行时 class
8. **textarea Enter 全屏蔽**（全局 keydown capture）
9. **--vh 真实视口** + **no-cache meta**

---

## 复用要点（执行前自检）

1. ✅ 不让用户在对话里发 key（GitHub 会扫描撤销）
2. ✅ Step 2（AI 开关）+ Step 3（格式选择）**必问**，不要擅自决定
3. ✅ 基础版用 `build_basic.py`，不要手改 reference.html
4. ✅ 部署前必跑 `verify.py`，P0 必须为 0
5. ✅ 部署用 `--force-local`（除非你明确要合并历史 snapshot）
6. ✅ 完整版 AI 调用前 `stripRuntimeForAI(cloned)`
7. ✅ 完整版 AI 密码必须先 unlock 再发 toast
8. ✅ 子元素 click 第一行 `stopPropagation()`
