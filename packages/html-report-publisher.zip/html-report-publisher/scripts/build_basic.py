#!/usr/bin/env python3
"""
基础版（enable_ai=false）一键转换脚本

把 reference.html 模板转成不带 AI 的基础版，输出到指定路径。

用法：
    python3 build_basic.py <output_path> [--title "页面标题"] [--author "作者"]

说明：
    - reference.html 是完整版（含 AI），本脚本严格做"减法"
    - 不动布局、不动 inline style、不动 JS 主流程
    - 只删 / 改：AI 相关 DOM、HELP_STEPS 文案、HELP_ANIMS SVG、关于页核心能力
    - 输出文件中 .container 区只有占位 h1 + subtitle，**实际汇报正文需要后续手工/脚本注入**
    - 注入正文后部署：deploy.py <output> --force-local
"""
import sys, re, argparse, pathlib

SKILL_DIR = pathlib.Path(__file__).resolve().parent.parent
TEMPLATE = SKILL_DIR / 'templates' / 'reference.html'


def load_template():
    return TEMPLATE.read_text(encoding='utf-8')


# ============ 1) HELP_STEPS：删掉 AI 步骤 ============
OLD_HELP_STEPS = """        const HELP_STEPS = {
            pc: [
                { num: 1, title: '⌘ 选中元素', desc: '⌘/Ctrl + 单击元素选中；或空白处拖动框选多个' },
                { num: 2, title: '💬 评论 + 导出', desc: '点气泡「💬 评论」写反馈；可【📤 导出全部】' },
                { num: 3, title: '✨ AI 修改 + 撤回', desc: '点气泡「✨ AI 修改」描述改动 → 3-15 秒生效；版本历史可撤回' }
            ],
            mobile: [
                { num: 1, title: '切批注 + 点元素', desc: '右上角【只读】→【批注】；点元素弹底部卡片' },
                { num: 2, title: '💬 评论 + 导出', desc: '卡片写反馈 → 发表；可【📤 导出全部】' },
                { num: 3, title: '✨ AI 修改 + 撤回', desc: '卡片描述改动 → AI 秒改；版本历史可撤回' }
            ]
        };"""
NEW_HELP_STEPS = """        const HELP_STEPS = {
            pc: [
                { num: 1, title: '⌘ 选中元素', desc: '⌘/Ctrl + 单击；空白处拖动可框选多个' },
                { num: 2, title: '💬 写评论', desc: '选中后点气泡【💬 评论】输入看法发送' },
                { num: 3, title: '📤 作者导出', desc: '作者一键导出所有反馈为 Markdown' }
            ],
            mobile: [
                { num: 1, title: '切到【批注】', desc: '右上角【只读】按钮点一下切成【批注】' },
                { num: 2, title: '点元素留言', desc: '点文字/数据 → 底部弹卡片 → 输入发送' },
                { num: 3, title: '📤 作者导出', desc: '作者一键导出所有反馈为 Markdown' }
            ]
        };"""

# ============ 2) HELP_ANIMS：6 个 SVG 重写（无 AI 字样，class="help-svg"） ============
NEW_HELP_ANIMS = '''const HELP_ANIMS = {
            "pc-1": `<svg class="help-svg" viewBox="0 0 280 200" xmlns="http://www.w3.org/2000/svg">
                <defs><style>
                    @keyframes c1 { 0%,20% { transform: translate(30px,160px); opacity:0; } 25% { opacity:1; } 60%,100% { transform: translate(140px,100px); opacity:1; } }
                    @keyframes e1 { 0%,55% { stroke:#ddd; fill:white; } 65%,100% { stroke:#667eea; stroke-width:2.5; fill:rgba(102,126,234,0.10); } }
                    .c1 { animation: c1 3s ease-out infinite; }
                    .e1 { animation: e1 3s linear infinite; }
                </style></defs>
                <rect x="30" y="40" width="220" height="24" rx="4" fill="#f0f0f0"/>
                <rect x="30" y="75" width="180" height="14" rx="3" fill="#f0f0f0"/>
                <rect class="e1" x="30" y="96" width="220" height="46" rx="6" stroke="#ddd" fill="white" stroke-width="1.5"/>
                <text x="140" y="124" text-anchor="middle" font-size="12" fill="#667eea" font-weight="600">待选中元素</text>
                <g class="c1"><path d="M0 0 L0 16 L4 12 L7 19 L9 18 L6 11 L12 11 Z" fill="#333" stroke="white" stroke-width="1"/></g>
                <text x="140" y="180" text-anchor="middle" font-size="11" fill="#333" font-weight="600">⌘/Ctrl + 单击选中</text>
            </svg>`,
            "pc-2": `<svg class="help-svg" viewBox="0 0 280 200" xmlns="http://www.w3.org/2000/svg">
                <defs><style>
                    @keyframes b2 { 0%,30% { opacity:0; transform:translateY(6px); } 45%,100% { opacity:1; transform:translateY(0); } }
                    @keyframes t2 { 0%,55% { opacity:0; } 70%,100% { opacity:1; } }
                    .b2 { animation: b2 2.8s ease-out infinite; }
                    .t2 { animation: t2 2.8s ease-out infinite; }
                </style></defs>
                <rect x="30" y="70" width="220" height="46" rx="6" stroke="#667eea" stroke-width="2.5" fill="rgba(102,126,234,0.10)"/>
                <text x="140" y="98" text-anchor="middle" font-size="12" fill="#667eea" font-weight="600">已选中</text>
                <g class="b2" transform="translate(60, 38)">
                    <rect width="90" height="28" rx="14" fill="#1a1a1a"/>
                    <text x="45" y="18" text-anchor="middle" fill="white" font-size="11" font-weight="600">💬 评论</text>
                </g>
                <g class="t2" transform="translate(30, 130)">
                    <rect width="220" height="44" rx="8" fill="#f7f8fc" stroke="#e0e0e0"/>
                    <text x="12" y="20" font-size="10" fill="#999">写评论…</text>
                    <text x="12" y="36" font-size="11" fill="#333">这里数据要再核对一下</text>
                </g>
            </svg>`,
            "pc-3": `<svg class="help-svg" viewBox="0 0 280 200" xmlns="http://www.w3.org/2000/svg">
                <rect x="20" y="30" width="240" height="140" rx="8" fill="white" stroke="#e0e0e0"/>
                <text x="140" y="58" text-anchor="middle" font-size="13" fill="#1a1a1a" font-weight="700">feedback.md</text>
                <line x1="40" y1="72" x2="240" y2="72" stroke="#f0f0f0"/>
                <text x="40" y="94" font-size="10" fill="#666">- [overview] 整体概览 · 2 条</text>
                <text x="40" y="114" font-size="10" fill="#666">- [chapter-1] 章节 1 · 5 条</text>
                <text x="40" y="134" font-size="10" fill="#666">- [chapter-2] 章节 2 · 8 条</text>
                <text x="140" y="178" text-anchor="middle" font-size="11" fill="#667eea" font-weight="600">📤 作者一键导出 Markdown</text>
            </svg>`,
            "mobile-1": `<svg class="help-svg" viewBox="0 0 200 280" xmlns="http://www.w3.org/2000/svg">
                <defs><style>
                    @keyframes bt { 0%,30% { fill:white; stroke:#e0e0e0; } 50%,100% { fill:#667eea; stroke:#667eea; } }
                    @keyframes bx { 0%,30% { fill:#666; } 50%,100% { fill:white; } }
                    .bt { animation: bt 2.4s ease-out infinite; }
                    .bx { animation: bx 2.4s ease-out infinite; }
                </style></defs>
                <rect x="30" y="20" width="140" height="240" rx="22" fill="white" stroke="#333" stroke-width="3"/>
                <rect class="bt" x="112" y="38" width="50" height="28" rx="6" fill="white" stroke="#e0e0e0" stroke-width="1.5"/>
                <text class="bx" x="137" y="56" text-anchor="middle" font-size="11" font-weight="600" fill="#666">批注</text>
                <rect x="45" y="85" width="110" height="10" rx="2" fill="#e0e0e0"/>
                <rect x="45" y="105" width="90" height="10" rx="2" fill="#e0e0e0"/>
                <text x="100" y="210" text-anchor="middle" font-size="11" fill="#333" font-weight="600">点【只读】→【批注】</text>
                <text x="100" y="228" text-anchor="middle" font-size="10" fill="#667eea">切到批注模式</text>
            </svg>`,
            "mobile-2": `<svg class="help-svg" viewBox="0 0 200 280" xmlns="http://www.w3.org/2000/svg">
                <defs><style>
                    @keyframes tap { 0%,30% { r:0; opacity:0.5; } 60% { r:18; opacity:0; } 100% { r:18; opacity:0; } }
                    @keyframes card { 0%,40% { transform: translateY(80px); opacity:0; } 55%,100% { transform: translateY(0); opacity:1; } }
                    .tap { animation: tap 2.6s ease-out infinite; }
                    .card { animation: card 2.6s ease-out infinite; }
                </style></defs>
                <rect x="30" y="15" width="140" height="260" rx="22" fill="white" stroke="#333" stroke-width="3"/>
                <rect x="45" y="65" width="110" height="44" rx="6" stroke="#667eea" stroke-width="2" fill="rgba(102,126,234,0.10)"/>
                <text x="100" y="92" text-anchor="middle" font-size="11" fill="#667eea" font-weight="600">元素</text>
                <circle class="tap" cx="100" cy="87" r="0" fill="#667eea"/>
                <g class="card" transform="translate(35, 155)">
                    <rect width="130" height="90" rx="10" fill="#f7f8fc" stroke="#e0e0e0"/>
                    <text x="12" y="22" font-size="10" fill="#999">写评论…</text>
                    <text x="12" y="42" font-size="10" fill="#333">数据要核对</text>
                    <rect x="12" y="58" width="106" height="22" rx="4" fill="#667eea"/>
                    <text x="65" y="73" text-anchor="middle" font-size="10" fill="white" font-weight="600">💬 发表评论</text>
                </g>
            </svg>`,
            "mobile-3": `<svg class="help-svg" viewBox="0 0 200 280" xmlns="http://www.w3.org/2000/svg">
                <rect x="20" y="30" width="160" height="200" rx="8" fill="white" stroke="#e0e0e0"/>
                <text x="100" y="58" text-anchor="middle" font-size="12" fill="#1a1a1a" font-weight="700">feedback.md</text>
                <line x1="35" y1="72" x2="165" y2="72" stroke="#f0f0f0"/>
                <text x="35" y="94" font-size="9" fill="#666">- overview · 2 条</text>
                <text x="35" y="114" font-size="9" fill="#666">- chapter-1 · 5 条</text>
                <text x="35" y="134" font-size="9" fill="#666">- chapter-2 · 8 条</text>
                <text x="100" y="200" text-anchor="middle" font-size="10" fill="#667eea" font-weight="600">📤 作者一键导出</text>
            </svg>`
        };'''


# ============ 3) 关于页：核心能力删 AI 实时改 / 版本可撤回 / 输密码三项 ============
ABOUT_PAT = re.compile(
    r"                stepsArea\.innerHTML = `\s*<div style=\"padding:8px 6px;line-height:1\.7;\">[\s\S]*?</div>\s*`;",
    re.MULTILINE
)
ABOUT_NEW = '''                stepsArea.innerHTML = `
                    <div style="padding:8px 6px;line-height:1.7;">
                        <h2 style="font-size:18px;margin:0 0 4px;color:#1f2937;">HTML 汇报助手</h2>
                        <p style="font-size:11px;color:#999;margin:0 0 14px;">基于 GitHub 云端 · 在线评论版</p>

                        <h3 style="font-size:13px;margin:0 0 6px;color:#1f2937;">🧩 是什么</h3>
                        <p style="font-size:12px;color:#555;margin:0 0 12px;">
                            把 Word / PPT / Markdown 方案转成 HTML，加上在线评论 + 多视图能力，一键部署到云端。生成一条链接发给老板/同事，打开就能看、能评。
                        </p>

                        <h3 style="font-size:13px;margin:0 0 6px;color:#1f2937;">❗ 解决什么问题</h3>
                        <p style="font-size:12px;color:#555;margin:0 0 12px;">
                            以前看方案 → 截图批注 → 拉群讨论 → 回去改稿 → 再发 → 反复几轮。<br>
                            现在打开链接直接在页面上评论，所有人看到的都是同一份最新版，反馈零成本、迭代秒级。
                        </p>

                        <h3 style="font-size:13px;margin:0 0 6px;color:#1f2937;">⚡ 核心能力</h3>
                        <ul style="font-size:12px;color:#555;padding-left:18px;margin:0 0 12px;line-height:1.8;">
                            <li><b>颗粒度评论</b> — 点任意文字/图片/数据直接评；PC 支持 ⌘+click 多选 / 拖动框选跨元素批量评</li>
                            <li><b>评论可筛选 · 可导出</b> — 方案 owner 一键导出全部反馈为 Markdown，丢给 WorkBuddy 批量返工</li>
                            <li><b>PC / 手机双视图</b> — 同链接自适应，能力一致（手机唯一区别：不支持拖动框选）</li>
                            <li><b>零安装</b> — 浏览器打开链接就能用，不装 App、不登录</li>
                        </ul>

                        <h3 style="font-size:13px;margin:0 0 8px;color:#1f2937;">🚀 怎么用</h3>
                        <p style="font-size:12px;color:#555;margin:0 0 10px;">按当前设备查看操作指南：</p>
                        <div style="display:flex;gap:12px;">
                            <button onclick="switchHelpDevice('pc')" style="flex:1;padding:12px;background:#f0f4ff;border:1.5px solid #667eea;border-radius:8px;cursor:pointer;font-size:13px;font-weight:600;color:#667eea;">💻 PC 端指南 →</button>
                            <button onclick="switchHelpDevice('mobile')" style="flex:1;padding:12px;background:#f0fdf4;border:1.5px solid #10b981;border-radius:8px;cursor:pointer;font-size:13px;font-weight:600;color:#10b981;">📱 手机端指南 →</button>
                        </div>
                    </div>
                `;'''


# ============ 4) DOM 删除：AI 按钮、AI tab、versionModal、aiSubToolbar ============
def strip_ai_dom(html: str) -> str:
    # bubbleToolbar AI 按钮 + 分隔线
    html = html.replace(
        '<button data-bubble-action="comment" title="写评论">💬 评论</button>\n        <span class="bubble-divider"></span>\n        <button data-bubble-action="ai" title="AI 实时修改">✨ AI 修改</button>',
        '<button data-bubble-action="comment" title="写评论">💬 评论</button>'
    )
    # commentPanel AI tab
    html = html.replace(
        '<button class="panel-tab" data-tab="ai" onclick="switchPanelTab(\'ai\')" style="flex:1;padding:10px;border:none;background:transparent;font-size:12px;cursor:pointer;color:#888;font-weight:500;border-bottom:2px solid transparent;">⚡ AI 修改</button>',
        ''
    )
    # aiSubToolbar
    html = re.sub(
        r'<div id="aiSubToolbar"[^>]*>[\s\S]*?</div>\s*(?=<div id="batchToolbar")',
        '', html, count=1
    )
    # versionModal
    html = re.sub(
        r'<!-- Version history modal -->\s*<div id="versionModal"[^>]*>[\s\S]*?</div>\s*</div>',
        '', html, count=1
    )
    # 手机底部抽屉 AI 按钮
    html = html.replace(
        '<button class="mcc-btn-ai" id="mccBtnAI" onclick="submitMobileComment(true)">✨ AI 修改</button>',
        ''
    )
    # mcc-tip 文案
    html = html.replace(
        '<div class="mcc-tip">评论留言不修改页面 · AI 修改会实时改 HTML</div>',
        '<div class="mcc-tip">欢迎留下你的想法</div>'
    )
    # mccInput placeholder
    html = html.replace(
        '<textarea id="mccInput" placeholder="输入评论或 AI 修改诉求..."></textarea>',
        '<textarea id="mccInput" placeholder="输入评论..."></textarea>'
    )
    # 评论面板底部提示
    html = html.replace(
        '<div style="margin-top:6px;font-size:10px;color:#999;line-height:1.5;" id="commentFooterHint">评论留言不修改页面</div>',
        '<div style="margin-top:6px;font-size:10px;color:#999;line-height:1.5;" id="commentFooterHint">💡 仅支持评论，欢迎圈选任意元素留下反馈</div>'
    )
    return html


# ============ 5) JS 补丁：openVersions 短路 + ENABLE_AI 常量 ============
# 注意：unlockKeys 和 __ENCRYPTED_KEYS__ 不再改动！
# 基础版也需要密码解密 token（评论读写 Gist 需要 token 鉴权）。
# deploy.py 会加密 token（不加密 ai_key），用户首次评论时输密码解锁。
def patch_js(html: str) -> str:
    # 添加 ENABLE_AI 常量（在 GIST_ID 之前）
    html = html.replace(
        "const GIST_ID = '__GIST_ID__';",
        """const ENABLE_AI = false;  // 基础版标记
        const GIST_ID = '__GIST_ID__';"""
    )
    # openVersions 短路
    html = re.sub(
        r"(        function openVersions\(\) \{)",
        r"\1\n            if (!ENABLE_AI) return;",
        html, count=1
    )
    return html


# ============ 6) HELP_STEPS / HELP_ANIMS / 关于页 替换 ============
def patch_help(html: str) -> str:
    assert OLD_HELP_STEPS in html, "HELP_STEPS 锚点未找到（reference.html 可能被改动）"
    html = html.replace(OLD_HELP_STEPS, NEW_HELP_STEPS, 1)

    # HELP_ANIMS 整块替换
    anims_pat = re.compile(r"const HELP_ANIMS = \{[\s\S]*?\n        \};", re.MULTILINE)
    m = anims_pat.search(html)
    assert m, "HELP_ANIMS 锚点未找到"
    html = html[:m.start()] + NEW_HELP_ANIMS + html[m.end():]

    # 关于页
    m = ABOUT_PAT.search(html)
    assert m, "关于页 stepsArea.innerHTML 锚点未找到"
    html = html[:m.start()] + ABOUT_NEW + html[m.end():]

    return html


# ============ 7) 添加：body.noai 类（CSS hooks）+ 健康检查 ============
def add_noai_hook(html: str) -> str:
    # 在 <body> 标签后立即插入 inline script 加 noai 类
    inject = '\n    <script>document.body.classList.add("noai");</script>'
    html = html.replace('<body>', '<body>' + inject, 1)
    return html


# ============ 8) container 替换为占位（用户后续注入正文） ============
def reset_container(html: str, title: str = '汇报标题（请替换）', subtitle: str = '请替换副标题'):
    container_pat = re.compile(r'<div class="container">[\s\S]*?</div>\n\n    <script>', re.MULTILINE)
    placeholder = f'''<div class="container">
        <h1>{title}</h1>
        <p class="subtitle">{subtitle}</p>

        <div class="commentable" data-section="placeholder">
            <p style="text-align:center; color:#999; padding:60px 20px;">
                此处为正文占位区。请用脚本/工具注入实际汇报内容（保留 .container 外壳和 .commentable 包装结构）。
            </p>
        </div>
    </div>

    <script>'''
    m = container_pat.search(html)
    assert m, "container 区未找到"
    return html[:m.start()] + placeholder + html[m.end():]


# ============ 主流程 ============
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('output_path')
    ap.add_argument('--title', default='汇报标题（请替换）')
    ap.add_argument('--subtitle', default='请替换副标题')
    args = ap.parse_args()

    html = load_template()
    html = strip_ai_dom(html)
    html = patch_js(html)
    html = patch_help(html)
    html = add_noai_hook(html)
    html = reset_container(html, args.title, args.subtitle)

    pathlib.Path(args.output_path).write_text(html, encoding='utf-8')
    print(f"✓ 基础版骨架已写入: {args.output_path}")
    print(f"  size: {len(html)} bytes")
    print()
    print("下一步：")
    print("  1. 在 .container 内注入实际汇报内容（保留 commentable 结构）")
    print("  2. 修改 sectionNames / TARGET_SELECTORS 匹配你的 section")
    print("  3. python3 verify.py {output} 跑健康检查")
    print(f"  4. python3 deploy.py {args.output_path} --force-local")


if __name__ == '__main__':
    main()
