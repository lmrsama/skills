#!/usr/bin/env python3
"""
convert.py - 把 Word / PPT / Markdown / txt 转成 HTML（保留原始格式）
用于 SKILL.md Step 2 用户选 B "保留原始格式" 时使用。

依赖（按需安装）：
  pip install python-docx python-pptx markdown beautifulsoup4

用法：
  python3 convert.py <input_file> -o <output.html>
"""
import sys, os, argparse, html, re
from pathlib import Path


STYLE_MINIMAL = """
<style>
  body { font-family: -apple-system, BlinkMacSystemFont, 'PingFang SC', sans-serif;
         max-width: 900px; margin: 0 auto; padding: 32px 20px; color: #333; background: #fff; }
  h1 { font-size: 24px; color: #1a1a1a; border-bottom: 2px solid #667eea; padding-bottom: 8px; margin-bottom: 16px; }
  h2 { font-size: 18px; color: #1a1a1a; margin-top: 28px; margin-bottom: 10px; }
  h3 { font-size: 15px; color: #333; margin-top: 20px; margin-bottom: 6px; }
  p { font-size: 14px; line-height: 1.75; margin-bottom: 10px; }
  ul, ol { font-size: 14px; line-height: 1.75; padding-left: 24px; margin-bottom: 12px; }
  li { margin-bottom: 4px; }
  table { width: 100%; border-collapse: collapse; margin: 12px 0; font-size: 13px; }
  th, td { border: 1px solid #e0e0e0; padding: 8px 12px; text-align: left; }
  th { background: #f5f5f5; font-weight: 600; }
  img { max-width: 800px; border-radius: 8px; margin: 10px 0; }
  code { background: #f5f5f5; padding: 2px 6px; border-radius: 3px; font-size: 13px; }
  pre { background: #f8f8f8; padding: 12px; border-radius: 6px; overflow-x: auto; }
  blockquote { border-left: 3px solid #667eea; padding-left: 12px; color: #666; margin: 12px 0; }
  .container { max-width: 900px; margin: 0 auto; }
  .commentable { margin-bottom: 24px; }
</style>
"""


def wrap_html(title, body_html):
    """包一层标准 HTML + commentable 结构"""
    return f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
  <meta http-equiv="Pragma" content="no-cache">
  <meta http-equiv="Expires" content="0">
  <title>{html.escape(title)}</title>
  {STYLE_MINIMAL}
</head>
<body>
  <div class="container">
    <h1>{html.escape(title)}</h1>
    <div class="commentable" data-section="content">
      {body_html}
    </div>
  </div>
  <!-- TODO: 注入 html-report-publisher 的交互增强（CSS/DOM/JS）
       参考 templates/reference.html 或 SKILL.md "注入参考" 章节 -->
</body>
</html>
"""


def from_markdown(path):
    try:
        import markdown
    except ImportError:
        raise SystemExit('pip install markdown')
    txt = Path(path).read_text(encoding='utf-8')
    body = markdown.markdown(txt, extensions=['tables', 'fenced_code', 'nl2br'])
    title = Path(path).stem
    # 尝试从第一行 # 提取标题
    m = re.match(r'^#\s+(.+)', txt)
    if m:
        title = m.group(1).strip()
    return wrap_html(title, body)


def from_docx(path):
    try:
        from docx import Document
    except ImportError:
        raise SystemExit('pip install python-docx')
    doc = Document(path)
    parts = []
    for p in doc.paragraphs:
        style = (p.style.name or '').lower()
        text = html.escape(p.text or '')
        if not text.strip():
            continue
        if 'heading 1' in style:
            parts.append(f'<h2>{text}</h2>')
        elif 'heading 2' in style:
            parts.append(f'<h3>{text}</h3>')
        elif 'heading 3' in style:
            parts.append(f'<h4>{text}</h4>')
        else:
            parts.append(f'<p>{text}</p>')
    # 表格
    for t in doc.tables:
        rows_html = []
        for i, row in enumerate(t.rows):
            cells = ''.join(f'<{"th" if i==0 else "td"}>{html.escape(c.text)}</{"th" if i==0 else "td"}>' for c in row.cells)
            rows_html.append(f'<tr>{cells}</tr>')
        parts.append('<table>' + ''.join(rows_html) + '</table>')
    title = Path(path).stem
    return wrap_html(title, '\n'.join(parts))


def from_pptx(path):
    try:
        from pptx import Presentation
    except ImportError:
        raise SystemExit('pip install python-pptx')
    prs = Presentation(path)
    parts = []
    for i, slide in enumerate(prs.slides):
        parts.append(f'<h2>Slide {i+1}</h2>')
        for shape in slide.shapes:
            if shape.has_text_frame:
                for p in shape.text_frame.paragraphs:
                    txt = html.escape(p.text or '').strip()
                    if txt:
                        parts.append(f'<p>{txt}</p>')
    title = Path(path).stem
    return wrap_html(title, '\n'.join(parts))


def from_txt(path):
    txt = Path(path).read_text(encoding='utf-8')
    paras = [f'<p>{html.escape(line)}</p>' for line in txt.split('\n\n') if line.strip()]
    title = Path(path).stem
    return wrap_html(title, '\n'.join(paras))


def main():
    ap = argparse.ArgumentParser(description='Word/PPT/MD/txt → HTML（保留原始格式）')
    ap.add_argument('input')
    ap.add_argument('-o', '--output', default=None)
    args = ap.parse_args()
    ext = Path(args.input).suffix.lower()
    handlers = {
        '.md': from_markdown, '.markdown': from_markdown,
        '.docx': from_docx, '.doc': from_docx,
        '.pptx': from_pptx, '.ppt': from_pptx,
        '.txt': from_txt,
    }
    fn = handlers.get(ext)
    if not fn:
        raise SystemExit(f'不支持的格式：{ext}，支持 .md / .docx / .pptx / .txt')
    out_html = fn(args.input)
    out_path = args.output or (Path(args.input).with_suffix('.html'))
    Path(out_path).write_text(out_html, encoding='utf-8')
    print(f'✓ 已生成：{out_path}')
    print(f'→ 下一步：把 templates/reference.html 的交互增强（CSS/DOM/JS）注入此文件，再跑 deploy.py')


if __name__ == '__main__':
    main()
