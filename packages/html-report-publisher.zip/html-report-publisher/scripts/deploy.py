#!/usr/bin/env python3
"""
部署HTML到GitHub Pages v2
- 从Gist拉取最新线上版本（保留AI修改内容）
- 合并本地HTML的框架和线上版本的container内容
- 加密密钥并替换占位符
- 推送GitHub Pages

合并策略（关键）：
  如果Gist中存在版本快照：
    用 线上最新的.container 覆盖 本地.container
  这样能保留：线上的AI修改结果
  同时更新：本地对框架（顶栏/评论面板/JS逻辑）的改动

用法：
  python3 deploy.py <html_path> --password xxx --repo yyy [--force-local]
"""
import sys, os, json, base64, argparse, hashlib, re
from pathlib import Path
import urllib.request, urllib.error

try:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
except ImportError:
    print("需要安装 cryptography: pip3 install cryptography")
    sys.exit(1)


CONFIG_PATH = Path(__file__).parent.parent / 'config.json'


def load_config():
    with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
        return json.load(f)


def encrypt_keys(token, ai_key, password):
    pwd_hash = hashlib.sha256(password.encode('utf-8')).digest()
    iv = os.urandom(12)
    aesgcm = AESGCM(pwd_hash)
    plaintext = json.dumps({'t': token, 'a': ai_key}).encode('utf-8')
    ciphertext = aesgcm.encrypt(iv, plaintext, None)
    blob = iv + ciphertext
    return base64.b64encode(blob).decode('ascii')


def github_api(method, path, token, body=None):
    url = f"https://api.github.com{path}"
    data = json.dumps(body).encode('utf-8') if body else None
    req = urllib.request.Request(url, data=data, method=method, headers={
        'Authorization': f'token {token}',
        'Accept': 'application/vnd.github+json',
        'Content-Type': 'application/json'
    })
    try:
        res = urllib.request.urlopen(req)
        body = res.read()
        return res.getcode(), json.loads(body) if body else None
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read()) if e.fp else None


def fetch_latest_snapshot_from_gist(gist_id, token):
    """从Gist读取versions.json，返回最新版本的snapshot（.container的outerHTML）"""
    code, data = github_api('GET', f'/gists/{gist_id}', token)
    if code != 200 or not data:
        return None
    files = data.get('files', {})
    if 'versions.json' not in files:
        return None
    try:
        versions = json.loads(files['versions.json']['content'])
        if not versions:
            return None
        latest = versions[-1]
        return {
            'snapshot': latest.get('snapshot'),
            'v': latest.get('v'),
            'time': latest.get('time'),
            'author': latest.get('author')
        }
    except Exception as e:
        print(f"  ⚠️ 解析versions.json失败: {e}")
        return None


def merge_with_online_snapshot(local_html, snapshot_html):
    """用线上snapshot的.container覆盖本地HTML的.container"""
    # 用正则提取 <div class="container">...</div>
    # 注意需要匹配嵌套的div
    def find_container(html):
        # 找 <div class="container"> 的开始
        match = re.search(r'<div[^>]*class="[^"]*container[^"]*"[^>]*>', html)
        if not match:
            return None
        start = match.start()
        # 从start开始配对div
        depth = 0
        pos = match.end()
        in_tag = False
        tag_buf = ''
        i = match.start()
        # 简化版：用DOM解析更稳
        return None

    # 更稳：用BeautifulSoup
    try:
        from bs4 import BeautifulSoup
    except ImportError:
        print("  ⚠️ 需要BeautifulSoup: pip3 install beautifulsoup4  | 跳过合并，直接用本地HTML")
        return local_html

    local_soup = BeautifulSoup(local_html, 'html.parser')
    snap_soup = BeautifulSoup(snapshot_html, 'html.parser')

    local_container = local_soup.find('div', class_='container')
    snap_container = snap_soup.find('div', class_='container') or snap_soup

    if not local_container:
        print("  ⚠️ 本地HTML找不到.container，跳过合并")
        return local_html

    # v2.11.15：剥离 snapshot 里残留的运行时 class（防止历史污染让所有用户看到默认选中态等）
    runtime_classes = {'selected-target', 'has-comments', 'has-edit-notes', 'open', 'active', 'panel-open', 'panel-expanded', 'show-comments', 'selection-mode', 'mobile-card-open'}
    for el in snap_container.find_all(True):
        existing = el.get('class')
        if existing:
            cleaned = [c for c in existing if c not in runtime_classes]
            if cleaned != existing:
                if cleaned:
                    el['class'] = cleaned
                else:
                    del el['class']
    # snap_container 自身也清
    if snap_container.get('class'):
        cleaned = [c for c in snap_container.get('class') if c not in runtime_classes]
        if cleaned:
            snap_container['class'] = cleaned
        elif 'class' in snap_container.attrs:
            del snap_container['class']
    # 移除运行时注入的元素
    for sel in ['.comment-badge', '.edit-note-badge', '.module-comment-btn', '.target-flag']:
        for n in snap_container.select(sel):
            n.decompose()

    # 用线上的container替换本地的
    local_container.replace_with(snap_container)
    return str(local_soup)


def deploy(html_path, password, repo_name, force_local=False):
    config = load_config()
    token = config['github_token']
    enable_ai = config.get('enable_ai', True)  # v1.1：基础版开关；默认 True 向后兼容
    ai_key = config.get('ai_api_key', '')
    gist_id = config['gist_id']
    user = config.get('github_user') or ''
    if not user:
        raise SystemExit('config.json 缺少 github_user 字段')
    if enable_ai and not ai_key:
        raise SystemExit('enable_ai=true 但 config.json 缺少 ai_api_key')

    print(f"▸ 读取本地HTML：{html_path}")
    with open(html_path, 'r', encoding='utf-8') as f:
        html = f.read()

    # 关键新增：从Gist拉取最新版本，合并
    if not force_local:
        print(f"▸ 检查线上Gist最新版本")
        latest = fetch_latest_snapshot_from_gist(gist_id, token)
        if latest and latest.get('snapshot'):
            # v2.11.19：如果 snapshot 含图片占位符（__IMG_PLACEHOLDER），说明是瘦身后的快照，不能用来合并（会丢图片）
            if '__IMG_PLACEHOLDER' in latest['snapshot']:
                print(f"  ⚠️ 线上 v{latest['v']} 含图片占位符，跳过合并，用本地HTML（图片完整）")
            else:
                print(f"  ✓ 发现线上 v{latest['v']}（{latest['author']} · {latest['time']}）")
                print(f"  ▸ 合并线上container → 本地HTML")
                html = merge_with_online_snapshot(html, latest['snapshot'])
        else:
            print(f"  ℹ️ 线上暂无版本快照，直接用本地HTML")
    else:
        print(f"  ⚠️ --force-local 模式：忽略线上版本，用本地HTML覆盖")

    # 加密密钥：基础版也需要加密 token（评论读写需要 token 鉴权 Gist API）
    # 区别：完整版加密 token + ai_key；基础版只加密 token（ai_key 留空）
    actual_ai_key = ai_key if enable_ai else ''
    print(f"▸ 加密密钥（密码：{password}）" + (" [基础版：仅 token，无 ai_key]" if not enable_ai else ""))
    encrypted = encrypt_keys(token, actual_ai_key, password)

    if '__ENCRYPTED_KEYS__' in html:
        html = html.replace('__ENCRYPTED_KEYS__', encrypted)
    else:
        # 如果已经被替换过了，用正则替换旧的加密块
        html = re.sub(
            r"(const ENCRYPTED_KEYS = ')[^']+(';)",
            r"\g<1>" + encrypted + r"\g<2>",
            html,
            count=1
        )

    # v2.0：注入 WORKER_BASE（腾讯云 SCF URL，中转 GitHub Gist 读写）
    # 前端不再持有任何 GitHub token，所有读写经 SCF，token 在 SCF env 里永不暴露
    # 安全模型：写操作校验 Origin + password + nickname；最坏被刷评论，不影响仓库代码
    worker_base = (config.get('worker_base') or '').rstrip('/')
    if not worker_base:
        print("⚠️ config.json 缺 worker_base（SCF URL），访客发评论将会失败")
        print("   部署 SCF 后把 URL 填进 config.worker_base；指南见 html-deploy-comments/scf/README.md")
    if '__WORKER_BASE__' in html:
        html = html.replace('__WORKER_BASE__', worker_base)
    else:
        html = re.sub(
            r"(const WORKER_BASE = ')[^']*(';)",
            r"\g<1>" + worker_base + r"\g<2>",
            html,
            count=1
        )

    # v1.2：替换 GIST_ID 占位符（此前模板写 __GIST_ID__ 但脚本未替换，评论功能失效）
    # v1.3 修复：仅当本地 HTML 含 __GIST_ID__ 占位符时才注入；
    # 如果本地 HTML 已有具体 GIST_ID（const GIST_ID = 'xxx'），尊重它，不覆盖。
    # 老 bug：旧版 deploy.py 用正则把任意 const GIST_ID = '...' 都替换成 publisher config 里的 gist_id，
    # 导致每个项目原有的评论 gist 被覆盖成 publisher 测试 gist，访客读到空数据。
    if '__GIST_ID__' in html:
        html = html.replace('__GIST_ID__', gist_id)
        print(f"▸ 注入 Gist ID：{gist_id}")
    else:
        # 检测本地 HTML 现有 GIST_ID
        m = re.search(r"const GIST_ID = '([^']+)';", html)
        if m and m.group(1) != gist_id:
            print(f"▸ 本地 HTML GIST_ID = {m.group(1)}（不同于 publisher config 的 {gist_id}）")
            print(f"  保留本地值，不覆盖（避免历史评论丢失）")
        # 不再做覆盖式正则替换

    print(f"▸ 检查/创建仓库：{repo_name}")
    code, data = github_api('GET', f'/repos/{user}/{repo_name}', token)
    if code == 404:
        code, data = github_api('POST', '/user/repos', token, {
            'name': repo_name, 'private': False, 'auto_init': True,
            'description': 'Report - online presentation'
        })
        if code >= 300:
            print(f"❌ 创建仓库失败 {code}: {data}"); sys.exit(1)
        print(f"  ✓ 仓库已创建")
    else:
        print(f"  ✓ 仓库已存在")

    print(f"▸ 上传 index.html")
    code, file_info = github_api('GET', f'/repos/{user}/{repo_name}/contents/index.html', token)
    payload = {
        'message': 'Update report',
        'content': base64.b64encode(html.encode('utf-8')).decode('ascii'),
    }
    if code < 300 and file_info and 'sha' in file_info:
        payload['sha'] = file_info['sha']
    code, data = github_api('PUT', f'/repos/{user}/{repo_name}/contents/index.html', token, payload)
    if code >= 300:
        print(f"❌ 上传失败 {code}: {data}"); sys.exit(1)
    print(f"  ✓ 已上传")

    print(f"▸ 启用 GitHub Pages")
    code, data = github_api('POST', f'/repos/{user}/{repo_name}/pages', token, {
        'source': {'branch': 'main', 'path': '/'}
    })
    if code in (201, 204):
        print(f"  ✓ Pages 已启用")
    elif code == 409:
        print(f"  ✓ Pages 已存在")
    else:
        print(f"  ⚠️ 启用Pages返回 {code}")

    url = f"https://{user}.github.io/{repo_name}/"
    print(f"\n✅ 部署完成")
    print(f"📍 URL：{url}")
    print(f"🔑 密码：{password}")


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('html_path')
    ap.add_argument('--password', default=None, help='访问密码，不填则从 config.json 读 deploy_password')
    ap.add_argument('--repo', default=None, help='目标仓库名，不填则从 config.json 读 deploy_repo')
    ap.add_argument('--force-local', action='store_true', help='忽略线上版本，强制用本地HTML覆盖（谨慎）')
    args = ap.parse_args()
    if not args.password or not args.repo:
        cfg = load_config()
        args.password = args.password or cfg.get('deploy_password')
        args.repo = args.repo or cfg.get('deploy_repo')
    if not args.password or not args.repo:
        raise SystemExit('请通过 --password / --repo 或在 config.json 配置 deploy_password / deploy_repo')
    deploy(args.html_path, args.password, args.repo, args.force_local)
