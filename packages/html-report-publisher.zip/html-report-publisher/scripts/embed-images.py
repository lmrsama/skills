#!/usr/bin/env python3
"""
HTML图片内嵌脚本
扫描HTML里所有本地图片引用，压缩+转base64内嵌。
用法：python3 embed-images.py <html_path>
"""
import sys
import os
import re
import base64
from pathlib import Path

try:
    from PIL import Image
except ImportError:
    print("需要安装Pillow: pip3 install Pillow")
    sys.exit(1)


def compress_and_encode(img_path, max_width=600, quality=85):
    """压缩图片并返回base64 data URI"""
    img = Image.open(img_path)
    if img.width > max_width:
        ratio = max_width / img.width
        img = img.resize((max_width, int(img.height * ratio)), Image.LANCZOS)
    if img.mode != 'RGB':
        img = img.convert('RGB')

    import io
    buf = io.BytesIO()
    img.save(buf, 'JPEG', quality=quality, optimize=True)
    b64 = base64.b64encode(buf.getvalue()).decode('utf-8')
    return f'data:image/jpeg;base64,{b64}', len(b64) // 1024


def embed_images(html_path):
    html_path = Path(html_path).resolve()
    html_dir = html_path.parent

    with open(html_path, 'r', encoding='utf-8') as f:
        html = f.read()

    # 匹配 src="..." 或 src='...'，排除 http/https/data: 开头
    pattern = re.compile(r'''src=(["'])((?!https?://|data:)[^"']+\.(?:png|jpg|jpeg|gif|webp))\1''', re.IGNORECASE)

    replacements = []
    total_saved = 0

    for match in pattern.finditer(html):
        quote, rel_path = match.group(1), match.group(2)
        abs_path = (html_dir / rel_path).resolve()

        if not abs_path.exists():
            print(f"  [skip] 图片不存在: {rel_path}")
            continue

        original_size = abs_path.stat().st_size // 1024
        data_uri, b64_size = compress_and_encode(abs_path)
        saved = original_size - b64_size
        total_saved += saved

        print(f"  [ok]   {rel_path}: {original_size}KB → {b64_size}KB")
        replacements.append((match.group(0), f'src={quote}{data_uri}{quote}'))

    for old, new in replacements:
        html = html.replace(old, new, 1)

    with open(html_path, 'w', encoding='utf-8') as f:
        f.write(html)

    final_size = html_path.stat().st_size // 1024
    print(f"\n完成：{len(replacements)}张图片内嵌")
    print(f"HTML最终大小：{final_size}KB")


if __name__ == '__main__':
    if len(sys.argv) != 2:
        print("用法: python3 embed-images.py <html_path>")
        sys.exit(1)
    embed_images(sys.argv[1])
