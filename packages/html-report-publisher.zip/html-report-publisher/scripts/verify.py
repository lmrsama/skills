#!/usr/bin/env python3
"""
健康检查：部署前对生成的 HTML 跑全套自检

用法：
    python3 verify.py <html_path>

退出码：
    0 = 全绿
    1 = 有 P0 错误（必须修复才能部署）
    2 = 有 P1 警告（建议修复）
"""
import sys, re, pathlib

P0 = []  # 致命错
P1 = []  # 警告


def check_basic(html: str):
    """基础版（enable_ai=false）专属检查"""
    is_basic = "document.body.classList.add(\"noai\")" in html or 'const ENABLE_AI = false' in html
    if not is_basic:
        return  # 完整版跳过此组检查

    # P0：底部不能有裸露 JS（最常见 bug）
    body_end = html.find('</body>')
    if body_end > 0:
        last_script_end = html.rfind('</script>', 0, body_end)
        tail = html[last_script_end:body_end].strip()
        if tail not in ('</script>', ''):
            # 允许 </script> 后只有空白和最多一个空注释
            non_ws = re.sub(r'</script>|<!--.*?-->|\s', '', tail, flags=re.DOTALL)
            if non_ws:
                P0.append(f"底部 </script> 后有裸露内容（前 100 字: {tail[:100]!r}）")

    # P0：所有 AI DOM 必须删除
    ai_residues = {
        'bubbleToolbar AI 按钮（可见 onclick）': re.search(r'<button[^>]+data-bubble-action="ai"[^>]+onclick', html),
        'panel AI tab（可见）': re.search(r'<button class="panel-tab"[^>]+data-tab="ai"', html),
        'mcc AI 按钮（可见）': re.search(r'<button[^>]+id="mccBtnAI"', html),
        'versionModal DOM': re.search(r'<div\s+id="versionModal"', html),
        'aiSubToolbar DOM': re.search(r'<div\s+id="aiSubToolbar"', html),
    }
    for name, m in ai_residues.items():
        if m:
            P0.append(f"基础版残留 AI DOM: {name}")

    # P0：HELP_STEPS 不能含"AI"
    m = re.search(r'const HELP_STEPS = \{[\s\S]*?\n        \};', html)
    if m and 'AI' in m.group(0):
        P0.append("HELP_STEPS 仍含 'AI' 字样")

    # P0：HELP_ANIMS 不能含"AI"
    m = re.search(r'const HELP_ANIMS = \{[\s\S]*?\n        \};', html)
    if m and 'AI' in m.group(0):
        P0.append("HELP_ANIMS 仍含 'AI' 字样（SVG <text> 中）")

    # P0：HELP_ANIMS 内 SVG 必须有 class="help-svg"
    if m:
        svg_count = len(re.findall(r'<svg [^>]*class="help-svg"', m.group(0)))
        if svg_count < 6:
            P0.append(f"HELP_ANIMS 内 SVG 缺少 class=\"help-svg\"（仅 {svg_count}/6 有）")

    # 注意：基础版也需要密码解锁 token（评论 Gist API 需要 token 鉴权）
    # 所以 unlockKeys 不应该被短路为 return null
    m = re.search(r'async function unlockKeys\(\) \{[\s\S]{0,200}', html)
    if m and 'return null' in m.group(0):
        P0.append("unlockKeys 被错误短路为 return null（评论功能需要 token！基础版也不能短路）")

    # __ENCRYPTED_KEYS__ 在 build 阶段保留占位是正常的（deploy 时替换）
    # 只有在已部署的 HTML 里仍为占位（deploy 没跑成功）才是问题 → 归入 P1（提醒）
    if "'__ENCRYPTED_KEYS__'" in html:
        P1.append("__ENCRYPTED_KEYS__ 占位还在 — deploy.py 会替换为加密数据；如果直接打开此文件，评论功能需要密码但解密会失败")


def check_common(html: str):
    """通用检查（基础版+完整版都检查）"""
    # P0：__GIST_ID__ 不能出现在最终 HTML（应被 deploy 替换）
    if '__GIST_ID__' in html:
        P1.append("__GIST_ID__ 占位还在 — 这通常没问题，deploy.py 会替换；如果你直接打开此文件，评论功能不工作")

    # P0：container 必须存在且唯一
    n_container = html.count('<div class="container">')
    if n_container == 0:
        P0.append("找不到 .container 容器")
    elif n_container > 1:
        P0.append(f"<div class=\"container\"> 出现 {n_container} 次（应唯一）")

    # P1：commentable section 数量
    sections = re.findall(r'<div\b[^>]*\bdata-section="([^"]+)"', html)
    if len(sections) < 2:
        P1.append(f"commentable section 仅 {len(sections)} 个，建议至少 2 个分块")

    # P0：sectionNames 中文映射应覆盖所有 data-section
    m = re.search(r'const sectionNames = \{([\s\S]*?)\};', html)
    if m:
        defined = set(re.findall(r"'([^']+)':", m.group(1)))
        used = set(sections)
        # 排除 JS 模板占位符
        used = {s for s in used if not s.startswith('${')}
        missing = used - defined - {'_global'}
        if missing:
            P1.append(f"sectionNames 缺少映射: {missing}")

    # P1：TARGET_SELECTORS 不应该是默认值（提醒用户替换）
    if "'.flow-node .node-title'" in html and 'feedback' in html.lower():
        # 用户可能没替换 TARGET_SELECTORS
        m = re.search(r'const TARGET_SELECTORS = \{[\s\S]*?\n        \};', html)
        if m and '.flow-node' in m.group(0) and '.theme-card' not in m.group(0):
            P1.append("TARGET_SELECTORS 看起来是默认（QB×YB 流程图）值，请按你的 section 替换")

    # P1：title 不应该是占位
    m = re.search(r'<title>([^<]+)</title>', html)
    if m and ('请替换' in m.group(1) or 'placeholder' in m.group(1).lower()):
        P1.append(f"<title> 是占位: {m.group(1)}")

    # P1：no-cache meta 应保留
    if 'http-equiv="Cache-Control"' not in html:
        P1.append("缺少 no-cache meta（用户硬刷新会失败）")

    # P0：脚注 your-name 占位
    if 'your-name' in html or '联系方式（请替换）' in html:
        P1.append("脚注/署名仍含 'your-name' 或 '联系方式（请替换）'")

    # P1：viewport meta
    if 'name="viewport"' not in html:
        P1.append("缺少 viewport meta（手机端会渲染异常）")


def main():
    if len(sys.argv) < 2:
        print("用法: python3 verify.py <html_path>")
        sys.exit(2)
    html = pathlib.Path(sys.argv[1]).read_text(encoding='utf-8')
    check_basic(html)
    check_common(html)

    print("=" * 60)
    print(f"健康检查: {sys.argv[1]}")
    print(f"  size: {len(html):,} bytes")
    print("=" * 60)

    if P0:
        print(f"\n❌ P0 致命错（{len(P0)}）— 必须修复后才能部署:")
        for x in P0:
            print(f"  - {x}")
    if P1:
        print(f"\n⚠️  P1 警告（{len(P1)}）— 建议修复:")
        for x in P1:
            print(f"  - {x}")
    if not P0 and not P1:
        print("\n✓ 全绿，可部署")

    sys.exit(1 if P0 else (2 if P1 else 0))


if __name__ == '__main__':
    main()
